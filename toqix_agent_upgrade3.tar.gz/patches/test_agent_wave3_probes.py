"""Agent upgrade 3 — wave-3 knowledge probe battery.

Twenty fresh questions a real user would ask (English + Roman Urdu
+ Urdu script), asked through the REAL HTTP API (POST
/api/agent/chat, dev auth) in a READY series — the strictest
context, where a question must outrank scene interpretation and
must never queue a job or get swallowed as flow input.

The battery boots its OWN isolated server: a temp copy of the
toqix package (fresh DB, lent curriculum domains file) on port
8973 with TOQIX_DEV_AUTH=1, so it is safe to run any time.

Each probe asserts: reply present, zero created jobs, no pending
chat job, none of the forbidden fallback shapes (character swallow
"Saved ✓", scene-confirm offer, capabilities menu, ready nudge),
and that the answer's content hits every expected group (any one
alternative per group; a probe may require only N of its groups —
see min_groups — for survey questions).

  python patches/test_agent_wave3_probes.py [--record OUT.json]

--record also dumps every raw reply to a JSON file (used to log
the pre-wave answers honestly before the fix).
"""
import http.cookiejar
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT = 8973
BASE = f"http://127.0.0.1:{PORT}"

FORBIDDEN = [
    "Saved ✓",                       # swallowed as character/flow input
    "Want me to queue this as Part",  # scene-confirm offer
    "Here's what I can do",           # capabilities menu dump
    "Your series is ready — send the next scene",  # ready nudge
    "Let me point you to what I do best",
]

# (id, lang, question, groups, min_groups)
# groups: every group needs >= 1 alternative (case-insensitive
# substring) in the reply, unless min_groups relaxes the count.
PROBES = [
    ("P01", "en", "What is a pan shot and when should I use it?",
     [["pan"], ["left", "right"]], None),
    ("P02", "en", "What is the difference between a zoom and a dolly move?",
     [["zoom"], ["dolly"], ["lens", "focal", "camera itself moves",
                            "camera moves", "physically moves"]], None),
    ("P03", "en", "How can I make the camera rise up and reveal the whole city in my video?",
     [["crane", "jib", "rising", "rises", "rise"], ["reveal"]], None),
    ("P04", "en", "What does a handheld camera look mean in a video prompt?",
     [["handheld", "hand-held", "hand held"],
      ["shake", "shaky"]], None),
    ("P05", "en", "Which camera move makes a scene feel tense and uneasy?",
     [["push-in", "push in", "dolly", "slow zoom"],
      ["dutch", "handheld", "tension", "unease", "uneasy"]], None),
    ("P06", "en", "What is a whip pan?",
     [["whip"], ["blur", "transition", "fast", "energy"]], None),
    ("P07", "en", "How do I keep the camera completely still in my video?",
     [["static", "locked-off", "locked off", "tripod"],
      ["still", "no movement", "not move", "stays"]], None),
    ("P08", "en", "What is rack focus in a shot?",
     [["focus"], ["shift", "pull", "foreground", "background",
                  "attention"]], None),
    ("P09", "en", "What is an FPV drone shot?",
     [["fpv"], ["drone"], ["fast", "dive", "dives", "through",
                            "first-person", "first person"]], None),
    ("P10", "en", "What is a tilt shot?",
     [["tilt"], ["up", "down"]], None),
    ("P11", "ru", "pan aur tilt mein kya farq hai?",
     [["pan"], ["tilt"]], None),
    ("P12", "ru", "camera ko bilkul still rakhna ho to prompt mein kya likhun?",
     [["static", "locked", "tripod"], ["still"]], None),
    ("P13", "ru", "dutch angle kya hota hai aur kab use karte hain?",
     [["dutch"], ["tilt", "slant", "unease", "uneasy", "tension"]], None),
    ("P14", "ru", "crane shot kya hai?",
     [["crane"], ["up", "rise", "rises", "upar", "oopar", "reveal"]], None),
    ("P15", "ru", "zoom karna behtar hai ya dolly move? farq batao",
     [["zoom"], ["dolly"], ["lens"]], None),
    ("P16", "ur", "ڈولی زوم کیا ہے؟",
     [["dolly zoom", "vertigo"], ["zoom"]], None),
    ("P17", "ur", "کیمرہ حرکت کی اقسام کون سی ہیں؟",
     [["pan"], ["tilt"], ["dolly", "crane"]], 2),
    ("P18", "ur", "پین شاٹ کیا ہوتا ہے؟",
     [["pan"], ["left", "right"]], None),
    ("P19", "ur", "ویڈیو میں کیمرہ بالکل ساکن رکھنا ہو تو کیا لکھوں؟",
     [["static", "locked", "tripod", "ساکن"], ["still", "movement"]], None),
    ("P20", "ur", "فضائی شاٹ کے لیے کون سی کیمرہ حرکت بہتر رہے گی؟",
     [["drone", "aerial"], ["above", "over", "fly"]], None),
]

RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name
          + (f" | {detail}" if detail else ""))


def boot_server():
    work = tempfile.mkdtemp(prefix="toqix_wave3_")
    shutil.copytree(ROOT / "toqix", os.path.join(work, "toqix"),
                    ignore=shutil.ignore_patterns("__pycache__"))
    domains = ROOT / "data" / "curriculum" / "domains.json"
    if domains.exists():
        dest = os.path.join(work, "data", "curriculum")
        os.makedirs(dest, exist_ok=True)
        shutil.copyfile(domains, os.path.join(dest, "domains.json"))
    # server.py mounts WEB_DIR (BASE_DIR/web) at import time; lend
    # the isolated copy the real web dir (read-only use, API tests).
    os.symlink(ROOT / "web", os.path.join(work, "web"))
    env = dict(os.environ,
               TOQIX_PORT=str(PORT), TOQIX_DEV_AUTH="1",
               TOQIX_GOOGLE_CLIENT_ID="dummy",
               TOQIX_SESSION_SECRET="dummy",
               # keeps the session cookie non-Secure so the local
               # http test client will send it (prod default is the
               # https PA URL, which marks cookies Secure)
               TOQIX_BASE_URL=BASE,
               PYTHONPATH=work)
    proc = subprocess.Popen(
        [sys.executable, "-m", "toqix.server"], cwd=work, env=env,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(60):
        try:
            with urllib.request.urlopen(BASE + "/api/health",
                                        timeout=2) as r:
                if r.status == 200:
                    return proc, work
        except Exception:
            time.sleep(0.5)
    proc.kill()
    raise RuntimeError("isolated server did not come up")


def main():
    record_path = None
    if "--record" in sys.argv:
        record_path = sys.argv[sys.argv.index("--record") + 1]
    proc, work = boot_server()
    jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(jar))

    def call(method, path, body=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(BASE + path, data=data,
                                     method=method)
        if data:
            req.add_header("Content-Type", "application/json")
        with opener.open(req) as resp:
            raw = resp.read().decode()
        try:
            return json.loads(raw) if raw else None
        except ValueError:
            return raw  # e.g. the /auth/dev redirect lands on HTML

    records = []
    try:
        call("GET", "/auth/dev?email=wave3@example.com&name=Wave3")
        # walk a series to ready: character -> style -> kind
        r = call("POST", "/api/agent/chat",
                 {"project_id": None,
                  "message": "a small robot with a red scarf"})
        pid = r["project"]["id"]
        call("POST", "/api/agent/chat",
             {"project_id": pid, "message": "cinematic"})
        r = call("POST", "/api/agent/chat",
                 {"project_id": pid, "message": "video"})
        assert r["state"] == "ready", f"setup failed: {r['state']}"
        print(f"series ready (project {pid})\n")

        for pid_probe, lang, text, groups, min_groups in PROBES:
            r = call("POST", "/api/agent/chat",
                     {"project_id": pid, "message": text})
            reply = r.get("reply") or ""
            low = reply.lower()
            need = min_groups or len(groups)
            hits = sum(1 for g in groups
                       if any(a.lower() in low for a in g))
            bad = [f for f in FORBIDDEN if f in reply]
            ok = (bool(reply) and r.get("created_jobs") == []
                  and not r.get("pending_chat_job") and not bad
                  and hits >= need
                  and r.get("state") == "ready")
            records.append({
                "id": pid_probe, "lang": lang, "q": text,
                "reply": reply, "groups_hit": hits,
                "groups_need": need, "forbidden": bad,
                "created_jobs": r.get("created_jobs"),
                "state": r.get("state"), "pass": ok})
            check(f"{pid_probe} [{lang}] {text[:52]!r}", ok,
                  f"groups {hits}/{need}"
                  + (f" forbidden={bad}" if bad else "")
                  + f" reply[:90]={reply[:90]!r}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
        shutil.rmtree(work, ignore_errors=True)

    if record_path:
        Path(record_path).write_text(
            json.dumps(records, indent=1, ensure_ascii=False))
        print(f"\nreplies recorded -> {record_path}")
    failed = [n for n, ok in RESULTS if not ok]
    print(f"\n{len(RESULTS) - len(failed)}/{len(RESULTS)} probes passed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
