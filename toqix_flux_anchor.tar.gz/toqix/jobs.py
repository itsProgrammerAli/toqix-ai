"""TOQIX job store — SQLite-backed queue for generation jobs.

A job is created on the website, exported as a *job package* JSON
(the file the Colab runner notebook reads from Google Drive), and
completed when the finished MP4 is imported back and normalized.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path

from . import config
from .prompt_engine import build_i2v_prompt, enhance_prompt

_LOCK = threading.Lock()

STATUSES = ("queued", "exported", "generating", "running", "done", "failed",
            "cancelled")
KINDS = ("video", "image", "audio", "chat")


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with _conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS jobs (
                id              TEXT PRIMARY KEY,
                prompt          TEXT NOT NULL,
                translated      TEXT DEFAULT '',
                enhanced_prompt TEXT NOT NULL,
                negative_prompt TEXT NOT NULL,
                style           TEXT NOT NULL,
                aspect          TEXT NOT NULL,
                duration        REAL NOT NULL,
                model           TEXT NOT NULL,
                seed            INTEGER NOT NULL,
                status          TEXT NOT NULL DEFAULT 'queued',
                output_path     TEXT DEFAULT '',
                thumb_path      TEXT DEFAULT '',
                package_path    TEXT DEFAULT '',
                error           TEXT DEFAULT '',
                rating          INTEGER NOT NULL DEFAULT 0,
                thumbs          INTEGER NOT NULL DEFAULT 0,
                consent         INTEGER NOT NULL DEFAULT 0,
                domain          TEXT NOT NULL DEFAULT '',
                kind            TEXT NOT NULL DEFAULT 'video',
                progress        INTEGER NOT NULL DEFAULT 0,
                project_id      TEXT DEFAULT NULL,
                user_id         TEXT DEFAULT NULL,
                priority        INTEGER NOT NULL DEFAULT 0,
                featured        INTEGER NOT NULL DEFAULT 0,
                claimed_by      TEXT DEFAULT NULL,
                claimed_at      REAL DEFAULT NULL,
                reply           TEXT DEFAULT NULL,
                reply_done      INTEGER NOT NULL DEFAULT 0,
                queued_jobs     TEXT NOT NULL DEFAULT '',
                created_at      REAL NOT NULL,
                updated_at      REAL NOT NULL
            )
            """
        )
        # Worker registry: every fleet worker pings in with the
        # capabilities it can serve (e.g. ["video", "chat"]); a worker
        # counts as online while its last ping is fresh (list_workers).
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS workers (
                name      TEXT PRIMARY KEY,
                caps      TEXT NOT NULL DEFAULT '[]',
                last_seen REAL NOT NULL DEFAULT 0,
                state     TEXT NOT NULL DEFAULT 'ready',
                current_job TEXT DEFAULT NULL,
                model_resident TEXT NOT NULL DEFAULT ''
            )
            """
        )
        # Migration for worker registries created before telemetry.
        _wcols = {row[1] for row in conn.execute("PRAGMA table_info(workers)")}
        for col, ddl in (
            ("state", "TEXT NOT NULL DEFAULT 'ready'"),
            ("current_job", "TEXT DEFAULT NULL"),
            ("model_resident", "TEXT NOT NULL DEFAULT ''"),
        ):
            if col not in _wcols:
                conn.execute(f"ALTER TABLE workers ADD COLUMN {col} {ddl}")
        # Key-value store for site-level signals (the GPU wake flag).
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS meta (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL DEFAULT ''
            )
            """
        )
        # Control Room tracking chips: every manager / scheduled
        # system upserts one row per component when it runs, so the
        # private /control dashboard can show who is alive.
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS heartbeats (
                component TEXT PRIMARY KEY,
                at        REAL NOT NULL DEFAULT 0,
                status    TEXT NOT NULL DEFAULT '',
                detail    TEXT NOT NULL DEFAULT ''
            )
            """
        )
        # Migration for databases created before the flywheel fields existed.
        existing = {row[1] for row in conn.execute("PRAGMA table_info(jobs)")}
        for col, ddl in (
            ("rating", "INTEGER NOT NULL DEFAULT 0"),
            ("thumbs", "INTEGER NOT NULL DEFAULT 0"),
            ("consent", "INTEGER NOT NULL DEFAULT 0"),
            ("domain", "TEXT NOT NULL DEFAULT ''"),
            ("kind", "TEXT NOT NULL DEFAULT 'video'"),
            ("progress", "INTEGER NOT NULL DEFAULT 0"),
            ("project_id", "TEXT DEFAULT NULL"),
            ("user_id", "TEXT DEFAULT NULL"),
            # Claim priority class (2026-10-17): 0 = a real user's
            # job, 1 = machine/batch (API-key automations). The
            # owner's website sign-in and his crons share ONE user
            # row (see server._current_user / auth.get_or_create_admin),
            # so user_id cannot separate them — this column can.
            ("priority", "INTEGER NOT NULL DEFAULT 0"),
            ("featured", "INTEGER NOT NULL DEFAULT 0"),
            ("claimed_by", "TEXT DEFAULT NULL"),
            ("claimed_at", "REAL DEFAULT NULL"),
            ("reply", "TEXT DEFAULT NULL"),
            ("reply_done", "INTEGER NOT NULL DEFAULT 0"),
            ("queued_jobs", "TEXT NOT NULL DEFAULT ''"),
            ("note", "TEXT NOT NULL DEFAULT ''"),
            # Speed telemetry (2026-10-17): first_claimed_at is set
            # ONCE at first claim and never refreshed by heartbeats
            # (claimed_at is), so submit->claim is measurable.
            # timings is a JSON dict of per-stage seconds a worker
            # posts with progress (model_load_s, generate_s,
            # sound_s, encode_s, job_total_s — whatever it measured).
            ("first_claimed_at", "REAL DEFAULT NULL"),
            ("timings", "TEXT NOT NULL DEFAULT ''"),
        ):
            if col not in existing:
                conn.execute(f"ALTER TABLE jobs ADD COLUMN {col} {ddl}")


def _row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    d["kind"] = d.get("kind") or "video"
    d["progress"] = int(d.get("progress") or 0)
    # Worker telemetry note (latest stage note posted with a progress
    # report, e.g. the sound stage's outcome) — '' when none was posted.
    d["note"] = d.get("note") or ""
    # Heavy flag: a 10s+ video is the heavy class of work (see
    # config.HEAVY_DURATION) — derived here, never stored, so rows
    # written before the flag existed behave exactly as before.
    try:
        _duration = float(d.get("duration") or 0)
    except (TypeError, ValueError):
        _duration = 0.0
    d["heavy"] = bool(d["kind"] == "video"
                      and _duration >= config.HEAVY_DURATION)
    # Sound design + scene structure + dialogue (video quality
    # upgrades): derived here, never stored — the prompt engine is
    # deterministic, so recomputing from the stored
    # prompt/style/aspect/duration gives exactly what create-time
    # enhancement produced, and jobs queued BEFORE these fields
    # existed gain them retroactively. Video jobs only; every
    # other kind carries the empty defaults, and the runner treats
    # missing/empty values as "no sound/scene instructions" and
    # falls back on its own. `dialogue` follows the same path
    # (sound design v2, 2026-10-17): {"line", "speaker"} when the
    # prompt quotes a spoken line, else None — the runner's
    # dialogue stage (phase 2) speaks the line over the SFX bed.
    d["sound_prompt"] = ""
    d["scenes"] = []
    d["dialogue"] = None
    if d["kind"] == "video":
        try:
            _extra = enhance_prompt(
                d.get("prompt") or "",
                style=d.get("style") or "cinematic",
                aspect=d.get("aspect") or config.DEFAULT_ASPECT,
                duration=_duration,
                domain_id=d.get("domain") or None,
                kind="video",
            )
            d["sound_prompt"] = _extra.get("sound_prompt", "")
            d["scenes"] = _extra.get("scenes", [])
            d["dialogue"] = _extra.get("dialogue")
            # Anchor->Motion lane (2026-10-19): a video job whose
            # style is "anchor" asks the heavy worker to render a
            # still first and animate THAT still with
            # Wan2.2-TI2V-5B instead of running text-to-video
            # alone. Derived here like the fields above, never
            # stored: the still prompt is the enhanced prompt
            # itself (the full shot formula); the motion prompt
            # is the wave-4 motion-only I2V prompt. Anchor jobs
            # are heavy-class at ANY duration (the 5B lane is
            # heavy work), so the heavy worker's heavy_only claim
            # filter always sees them; on any derivation error the
            # job simply stays a normal job.
            if (d.get("style") or "").strip().lower() == "anchor":
                d["anchor"] = True
                d["heavy"] = True
                d["anchor_prompt"] = (
                    _extra.get("enhanced_prompt", "") or "")
                try:
                    _i2v = build_i2v_prompt(
                        d["anchor_prompt"] or (d.get("prompt") or ""),
                        motion=_extra.get("translated") or "")
                    d["motion_prompt"] = _i2v.get("prompt", "") or ""
                except Exception:
                    d["motion_prompt"] = ""
        except Exception:
            d["sound_prompt"] = ""
            d["scenes"] = []
            d["dialogue"] = None
    # Anchor lane defaults: exactly "anchor" style opts in; every
    # other job (and every non-video kind) carries anchor off with
    # empty prompts, and the runner treats that as the normal path.
    if "anchor" not in d:
        d["anchor"] = False
        d["anchor_prompt"] = ""
        d["motion_prompt"] = ""
    # Series/agent jobs carry their project id; normal jobs are null.
    d["project_id"] = d.get("project_id") or None
    # Claim priority class (see the init_db migration note): rows
    # written before the column existed read as class 0.
    d["priority"] = int(d.get("priority") or 0)
    # Worker-mesh claim fields: who holds this job, and when the claim
    # was last touched (claim or progress heartbeat); null when unheld.
    d["claimed_by"] = d.get("claimed_by") or None
    _claimed_at = d.get("claimed_at")
    d["claimed_at"] = float(_claimed_at) if _claimed_at is not None else None
    _first = d.get("first_claimed_at")
    d["first_claimed_at"] = float(_first) if _first is not None else None
    try:
        d["timings"] = json.loads(d.get("timings") or "{}")
    except (TypeError, ValueError):
        d["timings"] = {}
    # Derived speed proof: submit->claim uses the FIRST claim stamp.
    if d["first_claimed_at"] is not None:
        d["submit_to_claim_s"] = round(d["first_claimed_at"]
                                       - float(d["created_at"]), 1)
    else:
        d["submit_to_claim_s"] = None
    # Chat jobs: the worker's reply text (None until one is posted),
    # whether the final reply landed, and the real creation jobs a
    # [[QUEUE ...]] directive in that reply produced.
    d["reply"] = d.get("reply") or None
    d["reply_done"] = int(d.get("reply_done") or 0)
    try:
        d["queued_jobs"] = json.loads(d.get("queued_jobs") or "[]")
    except (TypeError, ValueError):
        d["queued_jobs"] = []
    d["consent"] = bool(d.get("consent", 0))
    # API-surface aliases for the flywheel feedback contract:
    # train_consent mirrors consent; feedback renders thumbs as up/down.
    d["train_consent"] = d["consent"]
    d["feedback"] = {1: "up", -1: "down"}.get(int(d.get("thumbs", 0) or 0), "")
    width, height = config.size_for_aspect(d["aspect"])
    d["width"] = width
    d["height"] = height
    d["num_frames"] = config.frames_for_duration(d["duration"])
    d["fps"] = config.DEFAULT_FPS
    d["steps"] = config.DEFAULT_STEPS
    d["guidance"] = config.DEFAULT_GUIDANCE
    d["model_hf_id"] = config.MODELS.get(d["model"], {}).get("hf_id", "")
    # Model zoo routing record: the HF id of the zoo's ACTIVE entry
    # for this job's kind (heavy-aware for video). Derived here like
    # the other computed fields, never stored. The zoo is a plain
    # registry module, but if it ever fails to load the job simply
    # falls back to the config model string it already carries —
    # routing metadata must never break the queue.
    d["zoo_model"] = ""
    try:
        from . import model_zoo

        zoo_kind = model_zoo.JOB_KIND_TO_ZOO_KIND.get(d["kind"])
        if zoo_kind:
            entry = model_zoo.pick(zoo_kind, heavy=bool(d.get("heavy")))
            if entry:
                d["zoo_model"] = entry["id"]
    except Exception:
        d["zoo_model"] = ""
    if not d["zoo_model"]:
        d["zoo_model"] = d["model_hf_id"]
    return d


def job_package(job: dict) -> dict:
    """The exact JSON the Colab runner (notebook 03) consumes."""
    return {
        "job_id": job["id"],
        "prompt": job["enhanced_prompt"],
        "negative_prompt": job["negative_prompt"],
        "model": job["model"],
        "model_hf_id": job["model_hf_id"],
        "zoo_model": job.get("zoo_model", ""),
        "width": job["width"],
        "height": job["height"],
        "duration": job["duration"],
        "heavy": bool(job.get("heavy", False)),
        "sound_prompt": job.get("sound_prompt", ""),
        "dialogue": job.get("dialogue"),
        "scenes": job.get("scenes", []),
        "anchor": bool(job.get("anchor", False)),
        "anchor_prompt": job.get("anchor_prompt", ""),
        "motion_prompt": job.get("motion_prompt", ""),
        "num_frames": job["num_frames"],
        "fps": job["fps"],
        "steps": job["steps"],
        "guidance": job["guidance"],
        "seed": job["seed"],
        "kind": job.get("kind", "video"),
        "domain": job.get("domain", ""),
        "lora_name": config.LORA_NAME,
        "created_by": "TOQIX AI Studio",
    }


def export_package(job: dict) -> Path:
    path = config.EXPORTS_DIR / f"{job['id']}.json"
    path.write_text(json.dumps(job_package(job), indent=2), encoding="utf-8")
    return path


def create_job(
    prompt: str,
    style: str = "cinematic",
    aspect: str = config.DEFAULT_ASPECT,
    duration: float = config.DEFAULT_DURATION,
    model: str = config.DEFAULT_MODEL,
    seed: int = config.DEFAULT_SEED,
    consent: bool = False,
    domain: str = "",
    kind: str = "video",
    project_id: str | None = None,
    user_id: str | None = None,
    priority: int = 0,
) -> dict:
    if model not in config.MODELS:
        raise ValueError(f"unknown model: {model}")
    if aspect not in config.ASPECT_SIZES:
        raise ValueError(f"unknown aspect: {aspect}")
    if kind not in KINDS:
        raise ValueError(f"unknown kind: {kind}")

    if kind == "chat":
        # A chat job's prompt is a ready-made JSON conversation pack
        # for the fleet's LLM worker — it must reach the worker
        # byte-for-byte, so the prompt engine never touches it.
        enhanced = {
            "original": prompt, "translated": "",
            "enhanced_prompt": prompt, "negative_prompt": "",
            "domain": "",
        }
    else:
        enhanced = enhance_prompt(
            prompt, style=style, aspect=aspect, duration=duration,
            domain_id=domain or None, kind=kind,
        )
    job_id = uuid.uuid4().hex[:12]
    now = time.time()
    with _LOCK, _conn() as conn:
        conn.execute(
            """
            INSERT INTO jobs (id, prompt, translated, enhanced_prompt,
                              negative_prompt, style, aspect, duration,
                              model, seed, status, consent, domain, kind,
                              progress, project_id, user_id, priority,
                              created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued', ?, ?, ?, 0, ?, ?, ?, ?, ?)
            """,
            (
                job_id, enhanced["original"], enhanced["translated"],
                enhanced["enhanced_prompt"], enhanced["negative_prompt"],
                style, aspect, float(duration), model, int(seed),
                1 if consent else 0,
                domain or enhanced.get("domain", ""), kind,
                project_id or None, user_id or None,
                int(priority or 0), now, now,
            ),
        )
    job = get_job(job_id)
    pkg_path = export_package(job)
    with _LOCK, _conn() as conn:
        conn.execute(
            "UPDATE jobs SET package_path = ? WHERE id = ?",
            (str(pkg_path), job_id),
        )
    # Website-integrated GPU dispatch: if no worker is online, the
    # site itself raises the wake signal so a GPU gets started.
    if not any(w["online"] for w in list_workers()):
        request_wake(job_id, kind)
    return get_job(job_id)


def get_job(job_id: str) -> dict | None:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
    return _row_to_dict(row) if row else None


def list_jobs(limit: int = 100, include_chat: bool = False,
              owner_id: str | None = None,
              featured_only: bool = False) -> list[dict]:
    # Chat jobs are conversations, not creations: they stay out of the
    # public feed (and the dataset curation) unless include_chat is set.
    # Privacy scoping (accounts release): with featured_only, ONLY the
    # admin-featured showcase is visible (anonymous visitors); with
    # owner_id, that user's own jobs plus the featured showcase;
    # with neither, the full list (admin / machine access only — the
    # server enforces who may ask for it).
    clauses: list[str] = []
    params: list = []
    if not include_chat:
        clauses.append("kind != 'chat'")
    if featured_only:
        # Owner decision 2026-10-15: there is NO public showcase.
        # Signed-out visitors never see any creations.
        clauses.append("1 = 0")
    elif owner_id is not None:
        clauses.append("user_id = ?")
        params.append(owner_id)
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    with _conn() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs" + where
            + " ORDER BY created_at DESC LIMIT ?", (*params, limit)
        ).fetchall()
    return [_row_to_dict(r) for r in rows]


def list_project_jobs(project_id: str, limit: int = 500) -> list[dict]:
    """All jobs of one agent series project, oldest first (Part 1, 2, …)."""
    with _conn() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs WHERE project_id = ? AND kind != 'chat' "
            "ORDER BY created_at ASC LIMIT ?",
            (project_id, limit),
        ).fetchall()
    return [_row_to_dict(r) for r in rows]


def gallery(limit: int = 100, owner_id: str | None = None,
            featured_only: bool = False) -> list[dict]:
    # Same privacy scoping as list_jobs, over finished creations.
    scope = ""
    params: list = []
    if featured_only:
        # Owner decision 2026-10-15: no public showcase — always empty.
        scope = " AND 1 = 0"
    elif owner_id is not None:
        scope = " AND user_id = ?"
        params.append(owner_id)
    with _conn() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs WHERE status = 'done'" + scope
            + " ORDER BY updated_at DESC LIMIT ?",
            (*params, limit),
        ).fetchall()
    return [_row_to_dict(r) for r in rows]


def recent_job_count(user_id: str, seconds: float) -> int:
    """Jobs one user created inside a window (rate-abuse watch)."""
    with _conn() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM jobs WHERE user_id = ?"
            " AND created_at > ?",
            (user_id, time.time() - seconds),
        ).fetchone()
    return int(row["n"])


def queue_counts() -> dict:
    """Counts-only snapshot for the fleet watchdog / stats endpoint —
    never exposes prompts or owners."""
    with _conn() as conn:
        rows = conn.execute(
            "SELECT status, COUNT(*) AS n FROM jobs GROUP BY status"
        ).fetchall()
    counts = {r["status"]: r["n"] for r in rows}
    return {
        "queued": counts.get("queued", 0) + counts.get("exported", 0),
        "generating": counts.get("generating", 0),
        "done": counts.get("done", 0),
        "failed": counts.get("failed", 0),
        "cancelled": counts.get("cancelled", 0),
    }


def claim_next_waiting(worker: str,
                       handled_keys: list | None = None,
                       heavy_only: bool = False) -> dict | None:
    """Server-side claim for the worker mesh (accounts release).

    Workers no longer download the whole job list (it now carries
    per-user creations): they POST here and the server atomically
    claims the oldest waiting job for them. Claim order (2026-10-17
    owner-priority fix): priority class first — a real user's job
    (class 0) is ALWAYS claimed before a machine/batch job
    (class 1, the API-key automations: daily Shorts, self-tests),
    because the owner's own website sign-in and his crons share one
    user row, so only this class separates a person waiting on a
    result from a system batch that can drain behind them. Within a
    class: real user submissions ("queued") before legacy "exported"
    packages, oldest first. Same-content duplicates within the
    waiting pool collapse to one candidate, and content keys the
    worker already handled this session (``handled_keys``: [kind,
    prompt, aspect, duration, style]) are skipped, preserving the
    runner's dedupe behaviour.

    With ``heavy_only`` set, only heavy jobs (10s+ videos — see
    config.HEAVY_DURATION) are candidates: the Kaggle worker, whose
    GPU hours are reserved for the heavy class, takes those while
    the Colab fleet keeps working the normal queue oldest-first.
    """
    release_stale_claims()
    handled = {tuple(str(x) for x in key) for key in (handled_keys or [])}
    with _conn() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs WHERE status IN ('queued', 'exported')"
            " ORDER BY priority ASC,"
            " CASE status WHEN 'queued' THEN 0 ELSE 1 END,"
            " created_at ASC"
        ).fetchall()
    seen: set = set()
    for row in rows:
        job = _row_to_dict(row)
        if heavy_only and not job.get("heavy"):
            continue
        key = (str(job.get("kind") or "video"),
               str((job.get("prompt") or "").strip().lower()),
               str(job.get("aspect")), str(job.get("duration")),
               str(job.get("style")))
        if key in handled or key in seen:
            continue
        seen.add(key)
        claimed = claim_job(job["id"], worker)
        if claimed is not None:
            return claimed
    return None


def update_job(job_id: str, **fields) -> dict | None:
    allowed = {
        "status", "output_path", "thumb_path", "error", "package_path",
        "rating", "thumbs", "consent", "domain", "progress",
        "claimed_by", "claimed_at", "featured", "user_id", "note",
        "first_claimed_at", "timings",
    }
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return get_job(job_id)
    if "status" in fields and fields["status"] not in STATUSES:
        raise ValueError(f"bad status: {fields['status']}")
    if "progress" in fields:
        fields["progress"] = int(fields["progress"])
        if not (0 <= fields["progress"] <= 100):
            raise ValueError("progress must be 0-100")
    if "rating" in fields and not (0 <= int(fields["rating"]) <= 5):
        raise ValueError("rating must be 0-5")
    if "thumbs" in fields and int(fields["thumbs"]) not in (-1, 0, 1):
        raise ValueError("thumbs must be -1, 0 or 1")
    if "consent" in fields:
        fields["consent"] = 1 if fields["consent"] else 0
    fields["updated_at"] = time.time()
    assignments = ", ".join(f"{k} = ?" for k in fields)
    with _LOCK, _conn() as conn:
        conn.execute(
            f"UPDATE jobs SET {assignments} WHERE id = ?",
            (*fields.values(), job_id),
        )
    return get_job(job_id)


# ---------------------------------------------------------------------------
# Worker mesh — atomic claims.
#
# Many free-GPU sessions (Colab on any account, Kaggle, ...) can work the
# SAME queue in parallel: a worker atomically claims one waiting job, the
# claim is stamped with the worker's name, and progress posts act as a
# heartbeat that refreshes the stamp. If a session dies silently, its
# claim goes stale and the job returns to the pool automatically.
# ---------------------------------------------------------------------------

STALE_CLAIM_SECONDS = 45 * 60  # 45 minutes without a heartbeat = dead worker
WAITING_STATUSES = ("queued", "exported")


def release_stale_claims(max_age: float = STALE_CLAIM_SECONDS) -> int:
    """Return jobs held by (presumably dead) workers to the waiting pool.

    A claim is stale when the job is still 'generating' and its last
    claim / heartbeat stamp is older than ``max_age`` seconds. Returns
    how many jobs were released.

    The output_path is deliberately NOT consulted (bug fix 2026-10-17):
    job 14d45a56e358's worker uploaded its finished MP4 (output_path
    set, file served fine) and died before the final done post, so the
    old "no output" condition made the job un-releasable and it sat at
    progress 99 forever. A live worker heartbeats every few minutes,
    so 45 minutes of silence means the worker is gone whether or not
    an output path was stamped; the re-run simply regenerates.
    """
    cutoff = time.time() - max_age
    with _LOCK, _conn() as conn:
        cur = conn.execute(
            """
            UPDATE jobs
               SET status = 'queued', progress = 0,
                   claimed_by = NULL, claimed_at = NULL,
                   updated_at = ?
             WHERE status = 'generating'
               AND claimed_at IS NOT NULL
               AND claimed_at < ?
            """,
            (time.time(), cutoff),
        )
        return cur.rowcount


def claim_job(job_id: str, worker: str) -> dict | None:
    """Atomically claim one waiting job for ``worker``.

    The status check and the claim stamp happen inside a single
    BEGIN IMMEDIATE transaction, so two workers racing for the same job
    cannot both win: exactly one gets the job; the other gets None.
    Returns the claimed job dict, or None when the job is not waiting
    (already claimed, generating, done, failed, or unknown).
    """
    now = time.time()
    with _LOCK:
        conn = _conn()
        conn.isolation_level = None  # manual transaction control
        try:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT status FROM jobs WHERE id = ?", (job_id,)
            ).fetchone()
            if row is None or row["status"] not in WAITING_STATUSES:
                conn.execute("ROLLBACK")
                return None
            conn.execute(
                """
                UPDATE jobs
                   SET status = 'generating', progress = 1,
                       claimed_by = ?, claimed_at = ?, updated_at = ?,
                       first_claimed_at = COALESCE(first_claimed_at, ?)
                 WHERE id = ?
                """,
                (worker, now, now, now, job_id),
            )
            conn.execute("COMMIT")
        finally:
            conn.close()
    return get_job(job_id)


# ---------------------------------------------------------------------------
# Chat jobs — replies posted back by the fleet's LLM worker.
#
# A kind="chat" job carries a JSON conversation pack in its prompt.
# The worker that claims it streams its answer as reply snapshots
# (partial posts) and closes the job with one final post. The server
# post-processes the final text (see agent.parse_queue_directive)
# BEFORE it is stored here, so a stored reply is always clean.
# ---------------------------------------------------------------------------

def set_reply(job_id: str, text: str, final: bool = False) -> dict | None:
    """Store a worker's reply on a job. Returns the updated job, or
    None for an unknown id.

    ``text`` is the reply-so-far in full — workers send cumulative
    snapshots, not deltas. A partial post only updates the text; a
    final post also closes the job: status 'done', reply_done 1,
    progress 100, and the worker's claim released.
    """
    now = time.time()
    with _LOCK, _conn() as conn:
        if final:
            cur = conn.execute(
                """
                UPDATE jobs
                   SET reply = ?, reply_done = 1, status = 'done',
                       progress = 100, claimed_by = NULL,
                       claimed_at = NULL, updated_at = ?
                 WHERE id = ?
                """,
                (text, now, job_id),
            )
        else:
            cur = conn.execute(
                "UPDATE jobs SET reply = ?, updated_at = ? WHERE id = ?",
                (text, now, job_id),
            )
        if cur.rowcount == 0:
            return None
    return get_job(job_id)


def add_queued_jobs(job_id: str, new_ids: list[str]) -> dict | None:
    """Record creation jobs spawned from a chat job's reply (its
    [[QUEUE ...]] directive) on the chat job itself, so the chat
    poll endpoint can report them as ``queued_jobs``."""
    job = get_job(job_id)
    if job is None:
        return None
    merged = list(job.get("queued_jobs") or [])
    for nid in new_ids:
        if nid and nid not in merged:
            merged.append(nid)
    with _LOCK, _conn() as conn:
        conn.execute(
            "UPDATE jobs SET queued_jobs = ?, updated_at = ? WHERE id = ?",
            (json.dumps(merged), time.time(), job_id),
        )
    return get_job(job_id)


def list_chat_jobs(project_id: str | None, limit: int = 24) -> list[dict]:
    """Completed chat jobs of one conversation, oldest first.

    ``project_id`` None selects the lobby (chat jobs with no project).
    Only finished turns (reply_done) count — they are the agent's
    conversation history.
    """
    with _conn() as conn:
        if project_id:
            rows = conn.execute(
                "SELECT * FROM jobs WHERE kind = 'chat' AND reply_done = 1 "
                "AND project_id = ? ORDER BY created_at DESC LIMIT ?",
                (project_id, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM jobs WHERE kind = 'chat' AND reply_done = 1 "
                "AND project_id IS NULL "
                "ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
    return [_row_to_dict(r) for r in reversed(rows)]


# ---------------------------------------------------------------------------
# Worker registry — who is out there and what can they serve?
# ---------------------------------------------------------------------------

WORKER_ONLINE_SECONDS = 90  # a ping this old (or newer) = worker online


WORKER_STATES = ("cold", "warming", "ready", "busy")


def ping_worker(name: str, caps_list, state: str | None = None,
                current_job: str | None = None,
                model_resident: str | None = None) -> dict:
    """Upsert a worker's heartbeat: its name, the capability list it
    serves (e.g. ["video", "image", "chat"]) and the current time.

    Telemetry (2026-10-17 next-level fleet): a worker may also report
    its ``state`` (cold|warming|ready|busy), the job it is running
    and which model is resident on its GPU, so the Control Room can
    show a warm pool instead of a binary online flag. All three are
    optional — old workers that post only name+caps keep working,
    and a ping that omits a field never clears a reported value."""
    caps = [str(c) for c in (caps_list or [])]
    if state is not None and state not in WORKER_STATES:
        state = None
    now = time.time()
    with _LOCK, _conn() as conn:
        existing = conn.execute(
            "SELECT state, current_job, model_resident FROM workers"
            " WHERE name = ?", (name,)).fetchone()
        eff_state = state if state is not None else (
            existing["state"] if existing else "ready")
        eff_job = current_job if current_job is not None else (
            existing["current_job"] if existing else None)
        eff_model = model_resident if model_resident is not None else (
            existing["model_resident"] if existing else "")
        conn.execute(
            """
            INSERT INTO workers (name, caps, last_seen, state,
                                 current_job, model_resident)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET
                caps = excluded.caps, last_seen = excluded.last_seen,
                state = excluded.state,
                current_job = excluded.current_job,
                model_resident = excluded.model_resident
            """,
            (name, json.dumps(caps), now, eff_state, eff_job, eff_model),
        )
    # A worker checking in satisfies any outstanding GPU wake request.
    clear_wake()
    return {"name": name, "caps": caps, "last_seen": now, "online": True,
            "state": state, "current_job": current_job,
            "model_resident": model_resident}


def touch_worker(name: str, current_job: str | None = None) -> None:
    """Refresh a worker's last_seen from ANY authenticated contact —
    a progress post is proof of life exactly like a ping.

    Bug fixed 2026-10-17: workers report progress per job but ping
    on their own loop; when a ping was missed the registry showed
    workers_online=0 while a worker was actively generating and
    posting progress seconds earlier — and /api/stats + the wake
    logic both believed it. State becomes busy when a job is named.
    Never creates a registry row for an unknown name beyond a bare
    entry (caps stay whatever the worker last pinged)."""
    if not name:
        return
    now = time.time()
    with _LOCK, _conn() as conn:
        conn.execute(
            """
            INSERT INTO workers (name, caps, last_seen, state, current_job)
            VALUES (?, '[]', ?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET last_seen = excluded.last_seen,
                state = CASE WHEN excluded.current_job IS NOT NULL
                             THEN 'busy' ELSE workers.state END,
                current_job = COALESCE(excluded.current_job,
                                       workers.current_job)
            """,
            (name, now, "busy" if current_job else "ready", current_job),
        )


def list_workers() -> list[dict]:
    """All known workers with their caps and a computed ``online``
    flag (last ping within WORKER_ONLINE_SECONDS).

    A worker ALSO counts as online when it holds a generating job
    whose claim heartbeat (claimed_at, refreshed by every progress
    post) is fresh — progress IS a heartbeat, so the registry can
    never again read 0-online over an actively generating fleet."""
    now = time.time()
    with _conn() as conn:
        rows = conn.execute("SELECT * FROM workers ORDER BY name").fetchall()
        fresh_claimants = {
            r[0] for r in conn.execute(
                "SELECT DISTINCT claimed_by FROM jobs"
                " WHERE status = 'generating' AND claimed_by IS NOT NULL"
                " AND claimed_at > ?", (now - WORKER_ONLINE_SECONDS,))
        }
    workers = []
    for row in rows:
        d = dict(row)
        try:
            caps = json.loads(d.get("caps") or "[]")
        except (TypeError, ValueError):
            caps = []
        last_seen = float(d.get("last_seen") or 0)
        online = ((now - last_seen) <= WORKER_ONLINE_SECONDS
                  or d["name"] in fresh_claimants)
        workers.append({
            "name": d["name"],
            "caps": caps,
            "last_seen": last_seen,
            "online": online,
            # Control Room telemetry (next-level fleet, 2026-10-17):
            # an offline worker reads "cold" whatever it last said.
            "state": (d.get("state") or "ready") if online else "cold",
            "current_job": d.get("current_job") or None,
            "model_resident": d.get("model_resident") or "",
        })
    return workers


# ---------------------------------------------------------------------------
# Control Room — tracking chips (heartbeats) + dashboard aggregates.
#
# Managers and scheduled systems check in with upsert_heartbeat()
# (via POST /api/control/heartbeat, machine key only). The private
# /control page reads everything back through control_state helpers
# in the server, assembled from list_heartbeats(), the helpers below
# and the worker registry.
# ---------------------------------------------------------------------------

def upsert_heartbeat(component: str, status: str,
                     detail: str = "") -> dict:
    """Record one component's check-in (its tracking chip ping)."""
    component = str(component or "")[:80]
    status = str(status or "")[:40]
    detail = str(detail or "")[:500]
    now = time.time()
    with _LOCK, _conn() as conn:
        conn.execute(
            """
            INSERT INTO heartbeats (component, at, status, detail)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(component) DO UPDATE SET at = excluded.at,
                status = excluded.status, detail = excluded.detail
            """,
            (component, now, status, detail),
        )
    return {"component": component, "at": now,
            "status": status, "detail": detail}


def list_heartbeats() -> list[dict]:
    with _conn() as conn:
        rows = conn.execute(
            "SELECT * FROM heartbeats ORDER BY component").fetchall()
    return [dict(r) for r in rows]


def current_jobs_by_worker() -> dict:
    """Worker name -> the job it is generating right now (light
    fields for the control room). The freshest generating job wins
    when a name somehow holds more than one."""
    with _conn() as conn:
        rows = conn.execute(
            "SELECT claimed_by, id, kind, prompt, progress FROM jobs "
            "WHERE status = 'generating' AND claimed_by IS NOT NULL "
            "ORDER BY updated_at DESC"
        ).fetchall()
    out: dict = {}
    for r in rows:
        out.setdefault(r["claimed_by"], {
            "id": r["id"],
            "kind": r["kind"] or "video",
            "prompt": (r["prompt"] or "")[:60],
            "progress": int(r["progress"] or 0),
        })
    return out


def control_counts() -> dict:
    """queue_counts() plus calendar-day done/failed totals — the
    control room's stat cards."""
    import datetime

    counts = queue_counts()
    day_start = datetime.datetime.now().replace(
        hour=0, minute=0, second=0, microsecond=0).timestamp()
    with _conn() as conn:
        done_today = conn.execute(
            "SELECT COUNT(*) FROM jobs WHERE status = 'done' "
            "AND updated_at >= ?", (day_start,)).fetchone()[0]
        failed_today = conn.execute(
            "SELECT COUNT(*) FROM jobs WHERE status = 'failed' "
            "AND updated_at >= ?", (day_start,)).fetchone()[0]
    counts["done_today"] = int(done_today)
    counts["failed_today"] = int(failed_today)
    return counts


def chat_jobs_last_24h() -> int:
    with _conn() as conn:
        row = conn.execute(
            "SELECT COUNT(*) FROM jobs WHERE kind = 'chat' "
            "AND created_at > ?", (time.time() - 86400,)).fetchone()
    return int(row[0])


# ---------------------------------------------------------------------------
# GPU wake signal — the website itself asks for a GPU the moment a job
# lands while no worker is online. The fleet watchdog polls /api/wake
# and starts a worker; a worker's ping clears the request.
# ---------------------------------------------------------------------------

def _meta_get(key: str) -> str | None:
    with _conn() as conn:
        row = conn.execute(
            "SELECT value FROM meta WHERE key = ?", (key,)
        ).fetchone()
    return row[0] if row else None


def _meta_set(key: str, value: str) -> None:
    with _LOCK, _conn() as conn:
        conn.execute(
            """
            INSERT INTO meta (key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value
            """,
            (key, value),
        )


def _meta_del(key: str) -> None:
    with _LOCK, _conn() as conn:
        conn.execute("DELETE FROM meta WHERE key = ?", (key,))


def request_wake(job_id: str, kind: str) -> None:
    """Record that a GPU is needed. Keeps the FIRST unmet request, so
    ``since`` reflects the oldest job still waiting for a GPU."""
    if _meta_get("wake") is None:
        _meta_set("wake", json.dumps(
            {"since": time.time(), "job_id": job_id, "kind": kind}
        ))


def clear_wake() -> None:
    _meta_del("wake")


def wake_status() -> dict:
    """The site's GPU dispatch state: ``needed`` is true exactly when
    a wake was requested, jobs are still waiting, and no worker is
    online — the watchdog acts on this."""
    wake = None
    raw = _meta_get("wake")
    if raw:
        try:
            wake = json.loads(raw)
        except (TypeError, ValueError):
            wake = None
    with _conn() as conn:
        waiting, oldest = conn.execute(
            "SELECT COUNT(*), MIN(created_at) FROM jobs "
            "WHERE status IN ('queued', 'exported')"
        ).fetchone()
    online = sum(1 for w in list_workers() if w["online"])
    needed = bool(wake) and waiting > 0 and online == 0
    since = (wake or {}).get("since")
    if not needed and waiting > 0 and online == 0 and oldest is not None:
        # Jobs queued while a worker was alive never raised the flag.
        # If the fleet has since died and a job has been waiting a
        # while, that backlog IS a wake request.
        if time.time() - float(oldest) > 180:
            needed = True
            since = float(oldest)
    return {
        "needed": needed,
        "since": since,
        "job_id": (wake or {}).get("job_id"),
        "kind": (wake or {}).get("kind"),
        "waiting_jobs": waiting,
        "workers_online": online,
    }


init_db()
