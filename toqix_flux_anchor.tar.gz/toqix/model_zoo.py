"""TOQIX model zoo — the registry of open models TOQIX runs on.

TOQIX is not one model. It is a small zoo of best-in-class OPEN
models — one per job kind — behind one website and one queue, with
this module as the single place that records which model serves
which kind today, which models are evaluated candidates, and which
are merely on the watch list.

Honesty rules baked into this file:

* ``active`` means the fleet ACTUALLY runs it today — proven end to
  end on the owner's free GPUs (see the production log). Nothing is
  marked active for looking good on a leaderboard.
* ``candidate`` means evaluated on paper (license, size, VRAM fit,
  diffusers support) but NOT yet GPU-tested by us. Adoption is a
  deliberate step: GPU smoke test -> output QA -> flip the status
  here + update the runner -> owner-visible deploy. Never automatic.
* ``watch`` means known to exist and not yet evaluated. Sizes and
  licenses in watch entries are from public model cards and are
  UNVERIFIED — re-check them before any adoption step.
* There is no real-time weight learning anywhere in TOQIX, and the
  big closed models (Veo, Sora, ...) publish no weights at all, so
  they can never appear here. The zoo can only ever hold models
  whose weights are public.

Quality tiers are a rough internal scale: 1 = draft quality,
3 = solid production quality on free hardware, 5 = best open
weights available anywhere (usually needs a datacenter GPU).
Sizes are approximate total download sizes in GB; ``vram_gb`` is
the approximate peak VRAM of the way WE run it (with the runner's
offload / quantization recipe), not the vendor's headline number.
"""

from __future__ import annotations

KINDS = ("video", "image", "audio_tts", "audio_music", "chat")
STATUSES = ("active", "candidate", "watch")

# The job kinds in jobs.KINDS are coarser than the zoo's: a site
# "audio" job is a character-voice (TTS) job, so it routes to the
# zoo's audio_tts lane. audio_music is a stage inside video jobs
# (the sound bed), not a job kind of its own.
JOB_KIND_TO_ZOO_KIND = {
    "video": "video",
    "image": "image",
    "audio": "audio_tts",
    "chat": "chat",
}

MODELS: list[dict] = [
    # ------------------------------------------------------------------
    # ACTIVE — what the fleet runs today, proven end to end.
    # ------------------------------------------------------------------
    {
        "id": "Wan-AI/Wan2.1-T2V-1.3B-Diffusers",
        "name": "Wan 2.1 Text-to-Video 1.3B",
        "kind": "video",
        "task": "t2v",
        "license": "Apache-2.0",
        "size_gb": 13.0,
        "vram_gb": 14.0,
        "quality_tier": 2,
        "status": "active",
        "note": "The fleet's video engine since 2026-10-14 (runner "
                "notebook 03: 8-bit text encoder, sequential offload, "
                "fp16 — fits a free 16 GB T4). Small: famous "
                "characters and exact real-world details are weak; "
                "the prompt engine compensates where it can.",
    },
    {
        "id": "stabilityai/sdxl-turbo",
        "name": "SDXL Turbo",
        "kind": "image",
        "task": "t2i",
        "license": "Stability AI Community License (free for "
                   "research/personal and orgs under $1M revenue)",
        "size_gb": 7.0,
        "vram_gb": 8.0,
        "quality_tier": 3,
        "status": "candidate",
        "note": "The fleet's FALLBACK image engine since "
                "2026-10-19 (fp16, 4 steps, guidance 0.0). Fast "
                "and sharp, but it duplicates/fuses subjects "
                "(two dogs for one, proven repeatedly) — FLUX.1 "
                "Schnell is the default now; SDXL serves only "
                "when FLUX cannot run on a worker.",
    },
    {
        "id": "hexgrad/Kokoro-82M",
        "name": "Kokoro 82M",
        "kind": "audio_tts",
        "task": "tts",
        "license": "Apache-2.0",
        "size_gb": 0.35,
        "vram_gb": 1.0,
        "quality_tier": 3,
        "status": "active",
        "note": "The fleet's voice engine (6 character voices). "
                "Runs in the runner's isolated Python 3.12 venv; "
                "tiny enough to run on CPU if a GPU is busy.",
    },
    {
        "id": "facebook/musicgen-small",
        "name": "MusicGen Small",
        "kind": "audio_music",
        "task": "text-to-music",
        "license": "CC-BY-NC 4.0 (weights — non-commercial)",
        "size_gb": 3.0,
        "vram_gb": 4.0,
        "quality_tier": 2,
        "status": "candidate",
        "note": "FALLBACK / ambience layer since 2026-10-16 — MMAudio (video-conditioned) is the default sound stage now; MusicGen runs only if MMAudio fails. Previously generated the sound bed muxed onto every video (runner sound stage, fp16). Licence is "
                "NON-COMMERCIAL — fine for the owner's own channel "
                "experiments, must be revisited before any paid "
                "product use.",
    },
    {
        "id": "Qwen/Qwen2.5-7B-Instruct",
        "name": "Qwen 2.5 7B Instruct",
        "kind": "chat",
        "task": "chat",
        "license": "Apache-2.0",
        "size_gb": 15.0,
        "vram_gb": 10.0,
        "quality_tier": 3,
        "status": "active",
        "note": "The Agent's chat brain on the fleet (8-bit). "
                "Proven live 2026-10-14. Its Urdu is weak; the "
                "persona's language rule mitigates, a bigger Qwen "
                "is the candidate below.",
    },
    # ------------------------------------------------------------------
    # CANDIDATES — evaluated on paper, not yet GPU-tested by us.
    # ------------------------------------------------------------------
    {
        "id": "Qwen/Qwen3-8B",
        "name": "Qwen 3 8B",
        "kind": "chat",
        "task": "chat",
        "license": "Apache-2.0",
        "size_gb": 16.0,
        "vram_gb": 10.0,
        "quality_tier": 4,
        "status": "candidate",
        "note": "Next chat brain: already prepped in runner "
                "notebook 03 (CHAT_MODEL_ID, non-thinking mode) "
                "with automatic fallback to the active 7B. "
                "Adoption = the pending one-worker A/B test, then "
                "fleet deploy.",
    },
    {
        "id": "Wan-AI/Wan2.2-TI2V-5B",
        "name": "Wan 2.2 Text+Image-to-Video 5B",
        "kind": "video",
        "task": "t2v",
        "license": "Apache-2.0",
        "size_gb": 11.0,
        "vram_gb": 24.0,
        "quality_tier": 4,
        "status": "candidate",
        "note": "The natural video upgrade: 720p-native, much "
                "stronger motion than the 1.3B. Vendor says it fits "
                "a 24 GB consumer card — our free T4s have 16 GB, "
                "so adoption needs an offload/quantization smoke "
                "test before believing it.",
    },
    {
        "id": "Wan-AI/Wan2.1-T2V-14B-Diffusers",
        "name": "Wan 2.1 Text-to-Video 14B",
        "kind": "video",
        "task": "t2v",
        "license": "Apache-2.0",
        "size_gb": 65.0,
        "vram_gb": 40.0,
        "quality_tier": 4,
        "status": "candidate",
        "note": "Already listed in config.MODELS. Best Wan 2.1 "
                "quality, but it needs an A100-class GPU the free "
                "fleet does not have; candidate for any future "
                "paid-GPU day, not for the free fleet.",
    },
    {
        "id": "Wan-AI/Wan2.1-I2V-14B-480P-Diffusers",
        "name": "Wan 2.1 Image-to-Video 14B 480P",
        "kind": "video",
        "task": "i2v",
        "license": "Apache-2.0",
        "size_gb": 65.0,
        "vram_gb": 40.0,
        "quality_tier": 4,
        "status": "candidate",
        "note": "Animate-a-still variant, already listed in "
                "config.MODELS. Same A100 caveat as the 14B T2V. "
                "pick() never routes plain video jobs here — it "
                "only serves an explicit i2v task.",
    },
    {
        "id": "black-forest-labs/FLUX.1-schnell",
        "name": "FLUX.1 Schnell",
        "kind": "image",
        "task": "t2i",
        "license": "Apache-2.0 (verified on the HF card "
                   "2026-10-17; the dev variant is non-commercial "
                   "— schnell is the Apache one)",
        "size_gb": 34.1,
        "vram_gb": 12.0,
        "quality_tier": 4,
        "status": "active",
        "note": "The fleet's image engine since 2026-10-19. "
                "Drive deposit COMPLETE (34.06 GB diffusers "
                "subset, hash-verified). Smoke passed 2026-10-17 "
                "(astronaut + Pakistan flag: white stripe "
                "present, SDXL missed it). LIVE PROOF PASSED "
                "2026-10-19: job 25188ccc4cab on a Drive-mounted "
                "Colab worker, note 'image: flux' — 'a young boy "
                "playing with his dog' rendered exactly ONE boy "
                "and ONE puppy, photorealistic (the same prompt "
                "gave SDXL two dogs). Runs bf16 + sequential "
                "CPU offload on T4, weights staged to worker-"
                "local disk from the Drive mount. Kaggle "
                "workers cannot fetch the gated repo (401) and "
                "fall back to SDXL until the FLUX Kaggle "
                "dataset mirror lands.",
    },
    {
        "id": "sesame/csm-1b",
        "name": "Sesame CSM 1B",
        "kind": "audio_tts",
        "task": "tts",
        "license": "Apache-2.0 (verified on the HF card "
                   "2026-10-17)",
        "size_gb": 6.2,
        "vram_gb": 4.0,
        "quality_tier": 3,
        "status": "candidate",
        "note": "Conversational speech model — more natural "
                "prosody than Kokoro for dialogue-style audio. "
                "VERIFIED 2026-10-17 (HF API, blobs): full repo "
                "19.59 GB with heavy duplication (ckpt.pt 6.22 + "
                "model.safetensors 6.21 + transformers shards "
                "7.13 GB); the chosen deployable set is the "
                "TRANSFORMERS layout: shards 4,944,026,784 + "
                "2,189,474,180 bytes + configs/tokenizer (subset "
                "18 files / 7,158,362,991 bytes — the deposited "
                "transformers.safetensors.index.json matches "
                "this layout). GATE CLEARED: owner accepted the "
                "licence on HF account 'toqix' 2026-10-16; "
                "access RE-VERIFIED 2026-10-17 via the "
                "custom.huggingface connector (API 200; HEAD on "
                "ckpt.pt -> 302 signed CDN URL). The earlier "
                "'user step missing' verdict was WRONG. Deposit "
                "state 2026-10-17: all 16 small subset files ARE "
                "in Drive (incl. tokenizer.json 17,209,980 B, "
                "deposited by the VM hf_pipeline); ONLY the two "
                "weight shards are missing — the VM lane's "
                "multipart upload dies on them repeatedly "
                "(http2 internalError; shard-00002 attempts "
                "2026-10-17 logged in HANDOFF_model_vault_c2.md). "
                "The shards are in the ready-to-run Colab "
                "deposit notebook "
                "notebooks/06_toqix_model_deposit.ipynb. After "
                "they land: GPU test for voice consistency with "
                "the site's 6 character voices before adoption.",
    },
    {
        "id": "openai/whisper-small",
        "name": "Whisper Small",
        "kind": "audio_tts",
        "task": "asr",
        "license": "Apache-2.0 (verified on the HF card "
                   "2026-10-17)",
        "size_gb": 0.97,
        "vram_gb": 2.0,
        "quality_tier": 3,
        "status": "candidate",
        "note": "Speech-to-text for the finish-big pipeline: "
                "auto-captions, transcript QA of generated audio "
                "and user uploads (99 languages incl. Urdu — "
                "small is markedly stronger than base on "
                "low-resource languages). VERIFIED 2026-10-17 "
                "(HF API, blobs): NOT gated; full repo 3.87 GB "
                "is mostly redundant tf/flax/tf checkpoints — "
                "the trimmed safetensors set we deploy is "
                "0.97 GB (model.safetensors 967 MB + tokenizer/"
                "config files). Runs fp16 in ~2 GB VRAM on a T4 "
                "or on CPU. DOWNLOAD STATUS 2026-10-17: the "
                "trimmed set is downloaded LOCALLY and every "
                "file SHA-256-verified against the HF LFS "
                "hashes (model_cache/openai__whisper-small, 12 "
                "files, 971,388,090 bytes by local listing), "
                "but the Drive deposit is BLOCKED on the VM "
                "lane — the Drive CLI's multipart upload fails "
                "on the 967 MB weights file (repeated failures "
                "2026-10-17 incl. a first-hand retried attempt; "
                "exact evidence in HANDOFF_model_vault_c2.md; "
                "the CLI exposes no resumable/chunked mode — "
                "files create --upload is documented multipart "
                "only). Folder whisper-small exists in Drive "
                "models/ but is EMPTY (listing-verified "
                "2026-10-17). Deposit is covered by the "
                "ready-to-run Colab lane notebook "
                "notebooks/06_toqix_model_deposit.ipynb "
                "(ungated repo — no token needed); until it "
                "lands, workers resolving whisper-small fall "
                "back to the HF id. "
                "Adoption = runner transcription stage smoke "
                "test after the deposit.",
    },
    {
        "id": "xinntao/Real-ESRGAN",
        "name": "Real-ESRGAN (x4plus + v3 video weights)",
        "kind": "image",
        "task": "upscale",
        "license": "BSD-3-Clause (verified via the official "
                   "GitHub repo API 2026-10-17)",
        "size_gb": 0.08,
        "vram_gb": 2.0,
        "quality_tier": 3,
        "status": "candidate",
        "note": "AI upscale for the generate-small-finish-big "
                "pipeline — replaces today's Lanczos-only "
                "postprocess.upscale(). Weights-only deposit "
                "(the code is the GitHub repo, pip basicsr/"
                "realesrgan at worker setup): RealESRGAN_x4plus "
                "(67.0 MB, photos/stills x4), realesr-general-"
                "x4v3 + realesr-general-wdn-x4v3 (4.9 MB each, "
                "fast SRVGG video/general) and realesr-"
                "animevideov3 (2.5 MB). DOWNLOADED + DRIVE-"
                "VERIFIED 2026-10-17: Drive models/real-esrgan, "
                "5 files, 79,316,742 bytes, sizes matching the "
                "official GitHub release assets byte for byte. "
                "Adoption = worker postprocess smoke test.",
    },
    {
        "id": "hkchengrex/MMAudio",
        "name": "MMAudio (video-to-audio)",
        "kind": "audio_music",
        "task": "video-to-audio",
        "license": "CC-BY-NC 4.0 (weights — non-commercial); "
                   "code MIT",
        "size_gb": 6.0,
        "vram_gb": 6.0,
        "quality_tier": 3,
        "status": "active",
        "note": "DEFAULT sound stage since 2026-10-16 — GPU-proven live (job e265c83c8abc: 'sound: mmaudio ok (330s, large_44k_v2)'). Integrated in the runner as the MMAudio-first stage; MusicGen is fallback/ambience only. Verified at source 2026-10-16 (official GitHub "
                "repo + HF card). Generates sound CONDITIONED ON "
                "the rendered video frames — a Synchformer module "
                "aligns the audio to the frames — so sounds land "
                "when the action happens: synchronized by "
                "construction, the direct fix for the prompt-only "
                "MusicGen bed's mismatch and aage-peeche errors "
                "(owner's sound doctrine, 2026-10-16). Runs its "
                "own repo code (demo.py), NOT a diffusers "
                "pipeline; README documents ~6 GB VRAM for fp16 "
                "inference, so it fits a free 16 GB T4. size_gb "
                "is the recommended large_44k_v2 kit (3.9 GB flow "
                "net + 1.2 GB 44k VAE + 0.9 GB Synchformer); a "
                "small-16k kit totals ~2.6 GB. Caveats from the "
                "README itself: generated speech can be "
                "unintelligible and background music is not its "
                "strength — it is a sound-effects/sync stage, "
                "not a music composer, and the weights licence "
                "is NON-COMMERCIAL, the same restriction as the "
                "active MusicGen. Adoption = GPU smoke test as "
                "the runner's sound stage, then output QA. "
                "INTEGRATED 2026-10-16: vendored into the runner "
                "(mmaudio_bridge.py child process, upstream repo "
                "in vendor/mmaudio) as the DEFAULT sound stage "
                "in all 4 notebook copies — MusicGen is now the "
                "fallback ambience layer. Status stays candidate "
                "until the GPU smoke test passes; only then does "
                "it flip to active.",
    },
    # ------------------------------------------------------------------
    # WATCH — known, not yet evaluated. Sizes/licenses UNVERIFIED.
    # ------------------------------------------------------------------
    {
        "id": "THUDM/CogVideoX-5b",
        "name": "CogVideoX 5B",
        "kind": "video",
        "task": "t2v",
        "license": "CogVideoX model license (custom — verify "
                   "commercial terms before any use)",
        "size_gb": 11.0,
        "vram_gb": 16.0,
        "quality_tier": 3,
        "status": "watch",
        "note": "Alternative open video model family. Not "
                "evaluated: license terms and T4 offload fit both "
                "need checking first.",
    },
    {
        "id": "Lightricks/LTX-Video",
        "name": "LTX-Video (2B diffusers set, Drive-deposited)",
        "kind": "video",
        "task": "t2v",
        "license": "LTX-Video Open Weights License 0.X (custom; "
                   "licence text deposited inside the Drive "
                   "folder — commercial use permitted below "
                   "USD 10M annual revenue, paid licence above; "
                   "use restrictions apply)",
        "size_gb": 51.2,
        "vram_gb": 14.0,
        "quality_tier": 3,
        "status": "candidate",
        "note": "Known for very fast generation. VERIFIED "
                "2026-10-17: the FULL HF repo is 254.11 GB "
                "(HF API, blobs — 13B variants dominate; never "
                "download it whole; the earlier 111/127/206 GB "
                "estimates were all wrong in both directions). "
                "Drive HQ already holds a trimmed set (deposited "
                "2026-10-16 by the Colab lane; re-verified by "
                "recursive Drive listing 2026-10-17: 96 files, "
                "51.17 GB): the diffusers LTXPipeline (2B "
                "transformer 7.69 GB in 2 shards + T5-XXL text "
                "encoder 19.05 GB fp16 in 4 shards + VAE "
                "1.68 GB), three single-file 2B checkpoints "
                "(v0.9 9.37 GB, v0.9.5 6.34 GB, v0.9.1 5.72 GB) "
                "and the 13B distilled LoRA (1.33 GB, useless "
                "without its 13B base — the separate distilled "
                "repo's transformer alone is 31 GB and does NOT "
                "fit a T4). SPEED (the owner's #1 criterion "
                "since 2026-10-17): this is the fleet's fast-"
                "video candidate. The distilled 2B runs 8 steps "
                "at CFG 1.0 (the maker's own 0.9.8 distilled "
                "demo config); the LTX paper (arXiv 2501.00103) "
                "reports 5 s of 24 fps 768x512 in 2 s on an "
                "H100, and community timings put an 8-step "
                "distilled draft at 5-10 s on an RTX 4090 — a "
                "T4 is roughly 4-5x slower, so a realistic T4 "
                "estimate is ~1-3 min per 5 s 480p clip "
                "including Drive load (ESTIMATE — unproven "
                "until the fleet smoke test; the current Wan "
                "1.3B route took 18-37 min end to end per the "
                "owner, 2026-10-17). The one missing piece is "
                "the distilled transformer file itself: "
                "ltxv-2b-0.9.8-distilled.safetensors, exactly "
                "6,340,744,492 bytes in Lightricks/LTX-Video "
                "(an fp8 cut, 4,461,695,684 bytes, also "
                "exists); the Drive set's T5-XXL encoder + VAE "
                "are its companions. Deposit lane is READY: "
                "notebooks/06_toqix_model_deposit.ipynb lands "
                "it Google-side in one run (a 6.34 GB file "
                "cannot pass this VM's disk or the Drive CLI's "
                "multipart ceiling — both proven). T4 fit hinges on running the T5-XXL "
                "encoder 8-bit (the Wan runner recipe) + "
                "transformer offload — adoption = GPU smoke "
                "test, then QA vs Wan 1.3B on speed/quality. "
                "Fast Wan variants were also checked "
                "2026-10-17: LightX2V step-distill exists "
                "only for the 14B (does not fit) and its 1.3B "
                "repos carry NO licence metadata — rejected "
                "under the sahi gate, not downloaded.",
    },
    {
        "id": "hzwer/ECCV2022-RIFE",
        "name": "RIFE (frame interpolation)",
        "kind": "video",
        "task": "frame-interpolation",
        "license": "MIT (code, verified via the GitHub repo "
                   "API 2026-10-17); weights have no licence "
                   "metadata at any official source",
        "size_gb": 0.1,
        "vram_gb": 2.0,
        "quality_tier": 3,
        "status": "watch",
        "note": "The standard open frame-interpolation model "
                "(24->48 fps finishing for the generate-small-"
                "finish-big pipeline). Code is MIT, but the "
                "weights are distributed only through links in "
                "the GitHub README (Google Drive) and every HF "
                "copy is an unofficial mirror with no licence "
                "metadata (HF API search 2026-10-17) — that "
                "fails the owner's sahi (source-verified) gate "
                "for weight provenance, so nothing was "
                "downloaded. Interim finishing option is "
                "ffmpeg minterpolate (built in, no weights). "
                "Revisit if the author publishes weights in the "
                "repo/releases or an official HF repo appears.",
    },
    {
        "id": "stabilityai/stable-diffusion-3.5-medium",
        "name": "Stable Diffusion 3.5 Medium",
        "kind": "image",
        "task": "t2i",
        "license": "Stability AI Community License (custom, "
                   "non-permissive)",
        "size_gb": 48.9,
        "vram_gb": 10.0,
        "quality_tier": 4,
        "status": "watch",
        "note": "Possible SDXL successor for stills with better "
                "prompt following. EVALUATED + REJECTED "
                "2026-10-17 (HF API, blobs): repo is 48.86 GB "
                "and gated='auto' (licence-acceptance gate, "
                "same blocker as FLUX schnell) under a custom "
                "community licence — while FLUX.1-schnell is "
                "Apache-2.0 and the stronger stills model. "
                "Stays watch/rejected unless FLUX falls "
                "through entirely.",
    },
    {
        "id": "Qwen/Qwen3-14B",
        "name": "Qwen 3 14B",
        "kind": "chat",
        "task": "chat",
        "license": "Apache-2.0",
        "size_gb": 28.0,
        "vram_gb": 16.0,
        "quality_tier": 4,
        "status": "watch",
        "note": "Stronger chat brain, but at 8-bit it leaves no "
                "KV-cache headroom on a 16 GB T4 (already rejected "
                "once as OOM-prone). Revisit only with a bigger "
                "GPU or a proven 4-bit recipe.",
    },
    {
        "id": "character-ai/Ovi",
        "name": "Ovi (joint audio+video)",
        "kind": "video",
        "task": "t2av",
        "license": "Apache-2.0 (repo LICENSE — verified "
                   "2026-10-16)",
        "size_gb": 40.0,
        "vram_gb": 32.0,
        "quality_tier": 4,
        "status": "watch",
        "note": "Joint audio+video generation — a Twin-DiT "
                "(Wan 2.2 5B video branch + a 5B audio branch "
                "pretrained from scratch; borrows MMAudio's "
                "audio VAE) generates picture and sound TOGETHER, "
                "so sync is by construction: the long-term answer "
                "to the owner's sound doctrine. Verified at "
                "source 2026-10-16 (this entry is verified, "
                "unlike the older watch entries): checkpoints + "
                "inference code released Oct 2025, v1.1 (10 s) "
                "Nov 2025; own repo code — the id is the GitHub "
                "repo, whose download_weights.py pulls the "
                "weights from HF (each variant checkpoint is "
                "23.3 GB; a usable install is ~40 GB on disk). "
                "WHY WATCH, not candidate: the README requires "
                "~32 GB VRAM minimum WITH CPU offload (80 GB "
                "recommended; the community fp8 build still "
                "needs ~24 GB) — it does not fit the fleet's "
                "16 GB T4s in any documented configuration. "
                "Revisit when the fleet gets a bigger GPU, or a "
                "distilled/quantized release lands (both are on "
                "the repo's own TODO list).",
    },
]

_BY_ID = {m["id"]: m for m in MODELS}


def get(model_id: str) -> dict | None:
    """One zoo entry by HF id (a copy), or None."""
    entry = _BY_ID.get(model_id)
    return dict(entry) if entry else None


def entries(kind: str | None = None,
            status: str | None = None) -> list[dict]:
    """Registry entries (copies), optionally filtered."""
    out = []
    for m in MODELS:
        if kind is not None and m["kind"] != kind:
            continue
        if status is not None and m["status"] != status:
            continue
        out.append(dict(m))
    return out


def pick(kind: str, heavy: bool = False) -> dict | None:
    """The ACTIVE zoo entry serving ``kind`` — what the fleet runs.

    For video, only text-to-video entries route plain video jobs
    (the i2v variant never hijacks them). ``heavy`` (a 10s+ video)
    prefers the highest-tier active when more than one is active;
    today exactly one model per kind is active, so heavy changes
    nothing yet — it exists so the day a bigger video model goes
    active, heavy jobs route to it without code changes elsewhere.
    Returns None when a kind has no active entry (unknown kind
    raises ValueError instead — a typo must not silently route).
    """
    if kind not in KINDS:
        raise ValueError(f"unknown zoo kind: {kind}")
    actives = [m for m in MODELS
               if m["kind"] == kind and m["status"] == "active"]
    if kind == "video":
        actives = [m for m in actives if m.get("task") == "t2v"]
    if not actives:
        return None
    actives.sort(key=lambda m: (-int(m["quality_tier"]), m["id"]))
    return dict(actives[0])


def active_models() -> dict:
    """{zoo kind: {id, name, quality_tier}} for every served kind —
    the public face of the zoo (used by GET /api/zoo)."""
    out = {}
    for kind in KINDS:
        entry = pick(kind)
        if entry:
            out[kind] = {
                "id": entry["id"],
                "name": entry["name"],
                "quality_tier": entry["quality_tier"],
            }
    heavy = pick("video", heavy=True)
    if heavy:
        out["video_heavy"] = {
            "id": heavy["id"],
            "name": heavy["name"],
            "quality_tier": heavy["quality_tier"],
        }
    return out


def zoo_summary() -> dict:
    """Counts by status and kind, for status endpoints/reports."""
    by_status = {s: 0 for s in STATUSES}
    by_kind = {k: 0 for k in KINDS}
    for m in MODELS:
        by_status[m["status"]] = by_status.get(m["status"], 0) + 1
        by_kind[m["kind"]] = by_kind.get(m["kind"], 0) + 1
    return {
        "total": len(MODELS),
        "by_status": by_status,
        "by_kind": by_kind,
    }
