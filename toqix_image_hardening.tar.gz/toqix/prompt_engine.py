"""TOQIX prompt engine — TOQIX AI's own prompt layer.

Takes a short user prompt (English or Roman Urdu) plus style / aspect /
duration choices and expands it into a detailed, Wan-ready prompt:
subject + action + environment + camera movement + lighting + mood +
quality tokens, together with a matching negative prompt.

Fully deterministic (same input -> same output) and fully local:
dictionaries and templates only, no external calls of any kind.
"""

from __future__ import annotations

import hashlib
import re

from . import config
from .curriculum import detect_domain, get_domain

# ---------------------------------------------------------------------------
# Roman Urdu -> English (light-touch, content words only)
# ---------------------------------------------------------------------------
# Pure glue words are dropped; content words are translated. Anything the
# dictionary does not know passes through unchanged, so a mixed prompt
# still produces a sensible result.
_URDU_DROP = {
    "hai", "hain", "ka", "ki", "ke", "ko", "mein", "mai", "se", "par",
    "aur", "bhi", "tha", "thi", "ho", "raha", "rahi", "rahe", "ek",
    "yeh", "woh", "kya", "kab", "mera", "meri", "uska", "uski", "apna",
    "apni", "ne", "toh", "bana", "banao", "kar", "raha",
}

_URDU_WORDS = {
    # people
    "ladka": "young man", "ladki": "young woman", "bacha": "child",
    "bachi": "young girl", "aadmi": "man", "aurat": "woman",
    "buddha": "old man", "dost": "friend",
    # animals
    "billi": "cat", "kutta": "dog", "ghora": "horse", "hathi": "elephant",
    "sher": "lion", "cheeta": "cheetah", "bandar": "monkey",
    "parinda": "bird", "chiriya": "sparrow", "machhli": "fish",
    "titli": "butterfly", "kacchua": "turtle", "bhalu": "bear",
    # places / nature
    "pahad": "mountain", "pahar": "mountain", "pahadon": "mountains", "samandar": "ocean",
    "darya": "river", "jheel": "lake", "jangal": "forest",
    "registan": "desert", "gaon": "village", "sheher": "city",
    "ghar": "house", "makan": "building", "pul": "bridge",
    "aasman": "sky", "badal": "clouds", "chand": "moon",
    "suraj": "sun", "taare": "stars", "barish": "rain",
    "barf": "snow", "hawa": "wind", "zameen": "ground",
    "kheet": "field", "bagh": "garden", "phool": "flowers",
    "ped": "tree", "darakht": "tree",
    # objects / vehicles
    "gaari": "car", "gadi": "car", "gaadi": "car", "bus": "bus", "truck": "truck",
    "jahaz": "airplane", "kashti": "boat", "rocket": "rocket",
    "cycle": "bicycle", "ghari": "clock",
    # actions
    "bhaag": "running", "daud": "running", "chal": "walking",
    "naach": "dancing", "nach": "dancing", "gaa": "singing",
    "ro": "crying", "hans": "laughing", "so": "sleeping",
    "tair": "swimming", "ud": "flying", "khel": "playing",
    "kha": "eating", "pee": "drinking", "lad": "fighting",
    "doob": "setting", "doobta": "setting", "doobti": "setting",
    "ubhar": "rising", "ubharta": "rising", "ubharti": "rising",
    "ugta": "rising", "ugti": "rising",
    "nikal": "rising", "nikalta": "rising", "nikalti": "rising",
    # qualities / time
    "sundar": "beautiful", "khubsurat": "beautiful", "bara": "big",
    "chota": "small", "tez": "fast", "dheere": "slow", "naya": "new",
    "purana": "old", "subah": "morning", "shaam": "evening",
    "ghuroob": "sunset", "tulu": "sunrise", "tuloo": "sunrise",
    "maghrib": "dusk",
    "raat": "night", "din": "day", "laal": "red", "neela": "blue",
    "hara": "green", "peela": "yellow", "kala": "black",
    "safed": "white",
}


def _urdu_score(text: str) -> int:
    words = re.findall(r"[a-z]+", text.lower())
    known = sum(1 for w in words if w in _URDU_WORDS or w in _URDU_DROP)
    return known


def translate_roman_urdu(text: str) -> str:
    """Translate known Roman Urdu words; drop glue words; pass the rest
    through untouched. Returns (translated_text)."""
    out: list[str] = []
    for token in re.findall(r"[A-Za-z]+|[^A-Za-z]+", text):
        low = token.lower()
        if low in _URDU_DROP and token.isalpha():
            continue
        if low in _URDU_WORDS and token.isalpha():
            out.append(_URDU_WORDS[low])
        else:
            out.append(token)
    joined = "".join(out)
    return re.sub(r"\s+", " ", joined).strip(" ,") or text.strip()


# ---------------------------------------------------------------------------
# Style presets
# ---------------------------------------------------------------------------
STYLE_PRESETS: dict[str, dict] = {
    "cinematic": {
        "label": "Cinematic Film",
        "tokens": "cinematic film still, anamorphic lens, shallow depth of field, "
                  "dramatic composition, film grain, teal and orange grade",
        "lighting": "cinematic three-point lighting",
    },
    "photorealistic": {
        "label": "Photorealistic",
        "tokens": "photorealistic, ultra detailed skin and textures, shot on a "
                  "35mm camera, natural proportions, lifelike motion",
        "lighting": "natural realistic lighting",
    },
    "anime": {
        "label": "Anime",
        "tokens": "studio anime style, cel shaded, vibrant colors, clean line art, "
                  "expressive characters, sakuga-quality fluid animation",
        "lighting": "bright stylized anime lighting",
    },
    "3d_animation": {
        "label": "3D Animation",
        "tokens": "high-end 3D animated film style, soft subsurface scattering, "
                  "appealing character design, richly detailed sets, global illumination",
        "lighting": "warm studio-quality 3D lighting",
    },
    "vintage_film": {
        "label": "Vintage Film",
        "tokens": "vintage 1970s film footage, warm faded colors, visible film grain, "
                  "slight vignette, nostalgic documentary feel",
        "lighting": "soft period lighting",
    },
    "cyberpunk": {
        "label": "Neon Cyberpunk",
        "tokens": "cyberpunk aesthetic, neon signs, wet reflective streets, "
                  "holographic glow, high contrast night city",
        "lighting": "neon-lit night lighting with volumetric haze",
    },
    "nature_doc": {
        "label": "Nature Documentary",
        "tokens": "BBC-quality nature documentary footage, telephoto lens detail, "
                  "true-to-life animal behaviour, pristine wilderness",
        "lighting": "natural outdoor light",
    },
}
DEFAULT_STYLE = "cinematic"

# ---------------------------------------------------------------------------
# Scene intelligence: keyword-triggered camera / lighting / mood
# ---------------------------------------------------------------------------
_CAMERA_RULES: list[tuple[tuple[str, ...], str]] = [
    (("close", "face", "portrait", "eyes"), "slow push-in close-up shot"),
    (("fly", "flying", "sky", "aerial", "drone"), "sweeping aerial drone shot"),
    (("run", "running", "chase", "race", "racing", "fast"), "dynamic tracking shot following the action"),
    (("walk", "walking", "street", "stroll"), "smooth steadicam shot following alongside"),
    (("car", "drive", "driving", "road", "bike", "motorcycle"), "low tracking shot moving with the vehicle"),
    (("ocean", "sea", "beach", "wave", "water", "river", "lake"), "slow cinematic pan across the water"),
    (("dance", "dancing", "party", "music"), "orbiting camera shot circling the subject"),
    (("city", "building", "skyline", "traffic"), "slow crane shot rising over the scene"),
    (("space", "rocket", "moon", "moonlight", "planet", "star"), "slow majestic dolly shot through the scene"),
]

_CAMERA_FALLBACKS = [
    "slow cinematic dolly-in shot",
    "smooth slow-motion tracking shot",
    "gentle steadicam shot with subtle movement",
    "slow crane shot revealing the scene",
]

_LIGHTING_RULES: list[tuple[tuple[str, ...], str]] = [
    (("night", "midnight", "dark"), "moody moonlight with deep shadows"),
    (("sunset", "evening", "dusk", "golden"), "warm golden-hour sunlight"),
    (("sunrise", "dawn", "morning"), "soft fresh morning light"),
    (("rain", "raining", "storm", "monsoon"), "overcast stormy light with wet reflections"),
    (("snow", "winter", "frozen"), "crisp cold winter daylight"),
    (("neon", "cyberpunk", "club"), "vibrant neon lighting"),
    (("candle", "fire", "fireworks", "campfire", "lantern"), "warm flickering firelight"),
]

_MOOD_RULES: list[tuple[tuple[str, ...], str]] = [
    (("happy", "joy", "joyful", "celebrat", "fun", "funny", "smile", "smiling", "laugh", "laughing"), "joyful, uplifting mood"),
    (("sad", "lonely", "cry", "alone", "miss"), "melancholic, emotional mood"),
    (("scary", "horror", "ghost", "fear", "haunted"), "tense, eerie mood"),
    (("romantic", "love", "lovely", "wedding", "couple"), "tender romantic mood"),
    (("epic", "battle", "war", "hero", "heroes", "fight"), "epic, heroic mood"),
    (("peaceful", "calm", "relax", "relaxing", "meditat", "serene"), "peaceful, serene mood"),
]

_BASE_NEGATIVE = (
    "low quality, worst quality, blurry, out of focus, distorted, deformed, "
    "disfigured, extra limbs, extra fingers, missing limbs, morphing, "
    "flickering, jittery motion, static frame, frozen motion, watermark, "
    "logo, text, subtitles, cartoonish proportions (unless requested), "
    "oversaturated, noisy, grainy artifacts, duplicate subjects"
)


def _pick(seq: list[str], seed_text: str) -> str:
    digest = hashlib.md5(seed_text.encode("utf-8")).digest()
    return seq[digest[0] % len(seq)]


def _kw_match_bounded(text: str, keyword: str) -> bool:
    """Boundary-disciplined keyword match — the owl lesson
    (2026-10-17, job fdef9d8624db).

    The old raw-substring matcher let short keywords fire inside
    longer words: "owl" inside "slowly" locked an owl as the main
    subject of a TURTLE video, "car" inside "cartoon" claimed the
    vehicle camera, "war" inside "warm" forced epic mood, "cry"
    inside "crystal" forced melancholy. Same discipline the sound
    rules already use (_match_sound_rules), extended with plural
    forms (the _has_whole_word precedent):

    * multi-word phrases match with a letter boundary at both ends;
    * short keywords (<= 5 chars) match as whole words, with the
      plural forms "s" / "es" / "y"->"ies" allowed ("owls" still
      locks an owl, "foxes" still locks a fox);
    * longer keywords anchor at a word start, so deliberate stems
      keep working ("celebrat" -> celebration, "flying" -> flying).
    """
    k = keyword.lower()
    if " " in k:
        return re.search(
            rf"(?<![a-z]){re.escape(k)}(?![a-z])", text) is not None
    if len(k) <= 5:
        forms = [re.escape(k) + r"s?"]
        if k.endswith(("s", "x", "z", "ch", "sh")):
            forms.append(re.escape(k) + "es")
        if k.endswith("y"):
            forms.append(re.escape(k[:-1]) + "ies")
        return re.search(
            rf"(?<![a-z])(?:{'|'.join(forms)})(?![a-z])", text) is not None
    return re.search(rf"(?<![a-z]){re.escape(k)}", text) is not None


def _match_rules(rules, text: str):
    for keywords, value in rules:
        if any(_kw_match_bounded(text, k) for k in keywords):
            return value
    return None


# ---------------------------------------------------------------------------
# Boilerplate gating — the pickup-truck lesson (panda-snowman QA,
# 2026-10-15). Camera/domain heuristics injected vehicle and water
# language into prompts that never asked for those worlds:
#
#   * "a cartoon panda ..." matched the "car" camera rule by raw
#     substring and got "low tracking shot moving with the vehicle"
#     — the model dutifully rendered a teal pickup truck;
#   * a panda in the snow detected the ocean_weather domain, whose
#     defaults pasted "slow cinematic pan across the water" and
#     "dynamic sky and water" into a scene with no water at all.
#
# Rule now: a clause carrying vehicle or water terms survives ONLY
# when the user's own prompt implies that world — whole-word match,
# English + Roman Urdu, against both the translated text and the
# raw original (Roman Urdu implication words live in one or the
# other depending on whether translation ran). Everything else the
# engine adds (lighting, mood, consistency locks, flag designs,
# text legibility) is untouched, and the sound rules are a separate
# system that is NOT gated here.
# ---------------------------------------------------------------------------

_VEHICLE_USER_KEYWORDS = (
    "car", "gaari", "gadi", "truck", "bus", "train", "bike",
    "motorcycle", "bicycle", "cycle", "airplane", "plane", "jahaz",
    "boat", "kashti", "ship", "vehicle", "rickshaw", "road",
    "sarak", "drive", "driving",
)

_WATER_USER_KEYWORDS = (
    "water", "paani", "pani", "ocean", "samandar", "sea", "river",
    "darya", "lake", "jheel", "beach", "wave", "rain", "barish",
    "baarish", "waterfall", "aabshar", "underwater", "coast",
    "island", "pool", "swimming", "kinara", "lehar",
)

_VEHICLE_CLAUSE_TERMS = (
    "vehicle", "car", "truck", "bus", "train", "boat", "ship",
    "bike", "motorcycle", "airplane", "traffic",
)

_WATER_CLAUSE_TERMS = (
    "water", "ocean", "sea", "river", "lake", "wave", "beach",
    "underwater",
)


def _has_whole_word(text: str, words) -> bool:
    """True when any of `words` appears in `text` as a whole word
    (an optional plural "s" is allowed). The whole-word discipline
    is the point: "car" must not fire inside "cartoon", nor "sea"
    inside "season"."""
    return any(
        re.search(rf"(?<![a-z]){re.escape(w)}s?(?![a-z])", text)
        for w in words
    )


def _clause_allowed(clause: str, low: str, original_low: str) -> bool:
    """Gate one boilerplate clause against the user's own words.

    Vehicle-carrying clauses need a vehicle implication in the
    prompt; water-carrying clauses need a water implication. A
    clause with neither kind of term always passes."""
    c = (clause or "").lower()
    if _has_whole_word(c, _VEHICLE_CLAUSE_TERMS) and not (
        _has_whole_word(low, _VEHICLE_USER_KEYWORDS)
        or _has_whole_word(original_low, _VEHICLE_USER_KEYWORDS)
    ):
        return False
    if _has_whole_word(c, _WATER_CLAUSE_TERMS) and not (
        _has_whole_word(low, _WATER_USER_KEYWORDS)
        or _has_whole_word(original_low, _WATER_USER_KEYWORDS)
    ):
        return False
    return True


# ---------------------------------------------------------------------------
# Accuracy layer (v2) — the flag lesson. Small video models garble things
# that have ONE correct real-world form: national flags, emblems, written
# text. When a prompt touches one, spell the correct form out element by
# element inside the prompt itself; it measurably raises the hit rate, and
# the QA gate (frame-check, regenerate-once) catches the rest.
# ---------------------------------------------------------------------------

_FLAG_DESIGNS = [
    (("pakistan",), "the flag of Pakistan, shown accurately: a dark green flag with a white vertical stripe along the hoist side and a large white crescent moon and white five-pointed star centered in the green field, correct colors, correct design"),
    (("india", "indian", "tiranga"), "the flag of India, shown accurately: three horizontal bands of deep saffron orange on top, white in the middle and green at the bottom, with a navy-blue 24-spoke Ashoka Chakra wheel in the center of the white band, correct colors, correct design"),
    (("america", "american", "usa", "united states"), "the flag of the United States, shown accurately: thirteen horizontal red and white stripes with a blue canton in the top-left corner containing white stars, correct colors, correct design"),
    (("britain", "british", "uk", "united kingdom", "union jack"), "the Union Jack flag of the United Kingdom, shown accurately: a blue field with red and white diagonal and straight crosses combined, correct colors, correct design"),
    (("japan", "japanese"), "the flag of Japan, shown accurately: a plain white flag with one solid red circle exactly in the center, correct colors, correct design"),
    (("china", "chinese"), "the flag of China, shown accurately: a solid red flag with five golden-yellow stars in the top-left corner, one large star and four smaller stars, correct colors, correct design"),
    (("turkey", "turkish"), "the flag of Turkey, shown accurately: a solid red flag with a white crescent moon and a white five-pointed star, correct colors, correct design"),
    (("saudi",), "the flag of Saudi Arabia, shown accurately: a solid green flag with white Arabic calligraphy above a white horizontal sword, correct colors, correct design"),
    (("uae", "emirates", "dubai"), "the flag of the United Arab Emirates, shown accurately: three horizontal bands of green, white and black with a red vertical band at the hoist side, correct colors, correct design"),
    (("canada", "canadian"), "the flag of Canada, shown accurately: a white flag with red vertical bars on both sides and one red maple leaf exactly in the center, correct colors, correct design"),
    (("france", "french"), "the flag of France, shown accurately: three equal vertical bands of blue, white and red, correct colors, correct design"),
    (("germany", "german"), "the flag of Germany, shown accurately: three equal horizontal bands of black, red and gold-yellow, correct colors, correct design"),
    (("italy", "italian"), "the flag of Italy, shown accurately: three equal vertical bands of green, white and red, correct colors, correct design"),
    (("brazil", "brazilian"), "the flag of Brazil, shown accurately: a green flag with a large yellow diamond in the center holding a blue globe with white stars and a white banner, correct colors, correct design"),
    (("australia", "australian"), "the flag of Australia, shown accurately: a dark blue flag with the Union Jack in the top-left corner and white stars including one large seven-pointed star, correct colors, correct design"),
    (("palestine", "palestinian"), "the flag of Palestine, shown accurately: three horizontal bands of black, white and green with a red triangle at the hoist side, correct colors, correct design"),
    (("bangladesh",), "the flag of Bangladesh, shown accurately: a green flag with one large red circle slightly left of center, correct colors, correct design"),
]

_TEXT_KEYWORDS = (
    "text", "written", "writing", "words that say", "sign that says",
    "signboard", "logo", "caption", "title card", "likha", "likho",
)

_SUBJECT_KEYWORDS = (
    "panda", "robot", "cat", "dog", "elephant", "lion", "tiger", "fox",
    "turtle", "owl", "penguin", "whale", "horse", "astronaut", "boy", "girl",
    "man", "woman", "baby", "child", "billi", "kutta", "haathi",
)


def _detail_clauses(low: str) -> tuple[list[str], bool]:
    """Element-by-element accuracy clauses for a lowercased prompt.

    Returns (clauses, wants_text): clauses are appended to the visual
    prompt; wants_text means the negative prompt must stop banning
    text/logos because the user actually asked for them."""
    clauses: list[str] = []
    if _has_whole_word(low, ("flag", "jhanda", "parcham")):
        design = _match_rules(_FLAG_DESIGNS, low)
        if design:
            clauses.append(design)
        else:
            clauses.append(
                "the flag shown clearly, waving naturally, with its "
                "correct real-world colors and design"
            )
    wants_text = any(_kw_match_bounded(low, k) for k in _TEXT_KEYWORDS)
    if wants_text:
        clauses.append(
            "any text or lettering shown is crisp, correctly spelled, "
            "fully legible and exactly as requested"
        )
    subject = _match_rules(
        [( (k,), k) for k in _SUBJECT_KEYWORDS], low
    )
    if subject is None and _kw_match_bounded(low, "children"):
        # "children" is the plural the singular table entry cannot
        # reach with boundary matching; lock it as "child".
        subject = "child"
    if subject:
        clauses.append(
            f"one single {subject} as the main subject, identical "
            "appearance, colors and proportions in every frame"
        )
    return clauses, wants_text


# ---------------------------------------------------------------------------
# Image hardening — the duplication/fusion lesson (live QA,
# 2026-10-17; the owner complained formally). The fleet's image
# engine (SDXL-Turbo, 4 steps, guidance 0.0) renders a CFG of 0,
# which means the negative prompt is IGNORED — the only lever that
# reaches the render is explicit language in the POSITIVE prompt.
# Verified failures on live outputs:
#
#   * "a boy playing with his dog"      -> TWO dogs (the legacy
#     subject lock covered only the dog, the boy not at all, and
#     nothing anywhere said "do not duplicate");
#   * "A cute little boy Playing in garden" -> identical TWIN boys;
#   * "Dr DOOM"                          -> two heads fused on one
#     body (no subject keyword matched, so no lock existed);
#   * "a red sports car"                 -> body spliced from two
#     cars, three wheels on one side (vehicles were not subjects
#     at all in the lock table).
#
# Fix (image jobs only; video/audio/chat output is unchanged):
#   * COUNT LOCK — every detected singular main subject gets an
#     explicit "exactly one <subject>" clause in the engine's
#     normal clause stream (mid-prompt, not a tail);
#   * ANTI-DUPLICATION clause — concrete diffusion phrasing
#     ("no duplicate subjects, no twins, ...") right beside it;
#   * a titled/character prompt with no keyword subject (Dr DOOM)
#     gets a generic one-figure clause instead;
#   * PLURAL RESPECT — explicit counts/groups (EN + Roman Urdu)
#     switch ALL of it off: a user who asked for two brothers
#     must GET two brothers;
#   * NEGATIVE PROMPT — image jobs additionally carry the real
#     duplication/fusion/anatomy terms, so engines that DO honour
#     negatives (and the coming FLUX lane — FLUX follows explicit
#     count language well, which is why the positive clauses are
#     phrased as counts) get the full belt-and-braces.
# ---------------------------------------------------------------------------

# Image main subjects: the shared lock table plus the nouns the
# still-image lane meets constantly — vehicles and stock characters.
_IMAGE_SUBJECT_KEYWORDS = _SUBJECT_KEYWORDS + (
    "car", "motorcycle", "bicycle", "bird", "bear", "monkey",
    "deer", "rabbit", "superhero", "villain", "hero", "warrior",
    "knight", "wizard", "witch", "monster", "alien", "pirate",
    "soldier", "doctor", "teacher", "chef", "farmer", "person",
    "king", "queen", "prince", "princess",
)

# A prompt with no keyword subject can still be a single character
# ("Dr DOOM"): titles and figure words mark it as one figure.
_ENTITY_MARKERS = (
    "dr", "mr", "mrs", "miss", "captain", "professor", "character",
    "figure",
)

_PLURAL_COUNT_WORDS = (
    "two", "three", "four", "five", "six", "seven", "eight",
    "nine", "ten", "eleven", "twelve", "both", "twins",
    "triplets", "pair", "couple", "group", "crowd", "family",
    "team", "several", "multiple", "many",
)

_PLURAL_NOUNS = (
    "brothers", "sisters", "friends", "children", "kids", "boys",
    "girls", "men", "women", "people", "students", "players",
    "soldiers", "villagers",
)

# Roman Urdu plurals/counts — scanned ONLY on a prompt that leans
# Roman Urdu (the same >= 2 score gate translation uses), on the
# ORIGINAL text: translation rewrites or drops these words, and
# bare "teen"/"char" are innocent English on an English prompt.
_RU_PLURAL_WORDS = (
    "teen", "char", "paanch", "donon", "doston", "ladkon",
    "bachon", "log", "sare", "saray",
)

_ANTI_DUP_CLAUSE = (
    "no duplicate subjects, no twins, no mirrored copies, "
    "no extra heads or limbs, all subjects separate and unfused"
)

_ENTITY_CLAUSE = (
    "exactly one main subject, a single figure with one head "
    "and one body only, no duplicate subjects, no twins, "
    "no mirrored copies, no extra heads or limbs, "
    "no fused or merged bodies"
)

# Negative additions for image jobs. Single-subject images get the
# full identity set (duplication terms included); plural-intent
# images get only the fusion/anatomy terms, which cannot reduce a
# count the user actually asked for. (The base negative already
# carries "extra limbs" and "deformed" for every kind.)
_IMAGE_NEGATIVE_SINGLE = (
    ", duplicate, twins, cloned subject, two heads, extra heads, "
    "fused bodies, merged objects, malformed anatomy, "
    "conjoined bodies, fused limbs"
)
_IMAGE_NEGATIVE_PLURAL = (
    ", fused bodies, merged objects, malformed anatomy, "
    "conjoined bodies, fused limbs"
)


def _plural_intent(low: str, original: str) -> bool:
    """True when the user genuinely asked for MULTIPLES — explicit
    counts, group words or plural subject nouns, English + Roman
    Urdu. Boundary-disciplined throughout ("char" never fires
    inside "character", "men" never inside "women")."""
    original_low = (original or "").lower()
    for text in (low, original_low):
        if any(_kw_match_bounded(text, w) for w in _PLURAL_COUNT_WORDS):
            return True
        if any(_kw_match_bounded(text, w) for w in _PLURAL_NOUNS):
            return True
        if re.search(r"(?<![0-9a-z])(?:[2-9]|1[0-2])(?![0-9a-z])",
                     text):
            return True
        # Plural forms of any image subject noun ("red cars
        # parked in a row" asks for cars, plural, with no numeral).
        for kw in _IMAGE_SUBJECT_KEYWORDS:
            if _kw_match_bounded(text, kw + "s"):
                return True
            if _kw_match_bounded(text, kw + "es"):
                return True
            if kw.endswith("y") and _kw_match_bounded(
                    text, kw[:-1] + "ies"):
                return True
    if _urdu_score(original or "") >= 2:
        if any(_kw_match_bounded(original_low, w)
               for w in _RU_PLURAL_WORDS):
            return True
        # "do ladke", "do dost": the RU numeral 2 as a phrase
        # ("do" alone is also an English verb, so it only counts
        # in front of a person/animal noun).
        if re.search(
                r"(?<![a-z])do\s+(?:ladk|bach|dost|bhai|aadmi|"
                r"aurat|billi|kutt|ghor|bandar|parind)", original_low):
            return True
    return False


def _image_subjects(low: str) -> list[str]:
    """Singular main subjects of an image prompt, in order of
    appearance. Singular whole-word forms only: "boy" does not
    match inside "boys" (that is the plural path), "car" does not
    match inside "card" or "scar", "man" not inside "woman"."""
    found: list[tuple[int, str]] = []
    for kw in _IMAGE_SUBJECT_KEYWORDS:
        m = re.search(rf"(?<![a-z]){re.escape(kw)}(?![a-z])", low)
        if m:
            found.append((m.start(), kw))
    found.sort()
    return [kw for _, kw in found[:3]]


def _image_hardening_clauses(low: str, original: str) -> list[str]:
    """Positive-prompt count lock + anti-duplication clauses for
    a still image. Empty when the prompt asks for multiples."""
    if _plural_intent(low, original):
        return []
    subjects = _image_subjects(low)
    if not subjects:
        if any(_kw_match_bounded(low, w) for w in _ENTITY_MARKERS):
            return [_ENTITY_CLAUSE]
        return []
    if len(subjects) == 1:
        count = (f"exactly one {subjects[0]}, "
                 f"a single {subjects[0]} only")
    else:
        singles = [f"exactly one {s}" for s in subjects]
        count = ", ".join(singles[:-1]) + f" and {singles[-1]}"
        count += ", one of each only"
    return [count, _ANTI_DUP_CLAUSE]


# ---------------------------------------------------------------------------
# Sound + scene structure (video quality upgrade, 2026-10-15)
#
# Wan renders SILENT video: the owner received a 10s clip with no
# audio track at all and no story logic (one frozen pose). Two
# deterministic fixes live here:
#
# * sound_prompt — an SFX-first description of the sounds the
#   video's OWN action makes (v2, 2026-10-17 — see the sound-design
#   section below). The runner conditions MMAudio on this text and
#   muxes the result onto the video. v1 emitted a music-bed
#   description for nearly every job; the fleet faithfully
#   synthesized music instead of action sounds, and the owner
#   rejected that outright: sound must match the action, music
#   only when the prompt asks for it or the scene is musical.
#
# * dialogue — when the prompt carries a quoted spoken line, the
#   exact line (plus a speaker hint) is extracted so the runner
#   can speak THE ACTUAL WORDS (Kokoro) over the SFX in phase 2.
#
# * scenes — heavy videos (duration >= config.HEAVY_DURATION) split
#   into TWO scene prompts: a setup beat and an action/payoff beat.
#   Both carry the SAME character anchor text verbatim (the subject
#   sentence plus the subject-consistency lock clause when one was
#   built), so the character cannot drift between the two clips the
#   runner renders and concatenates.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Sound design v2 — SFX FIRST (owner's correction, 2026-10-17).
#
# v1 (above, in git history) emitted a MusicGen-style MUSIC
# description for nearly every video: a fox jumping into autumn
# leaves got "energetic cinematic electronic music, rhythmic
# pulses" (the vehicles domain bed), a turtle crossing a stream
# got "dreamy ambient electronic music" (abstract_art bed), and
# "Dr doom fighting with avengers" got the neutral default
# "cinematic ambient music matching the scene mood" — it missed
# even the battle bed, because "fight" (5 chars) needed a
# whole-word match and the prompt says "fighting". MMAudio was
# conditioned on those texts, so it faithfully synthesized music
# beds instead of the sounds of the action.
#
# The owner's law: SOUND MATCHES THE ACTION. A hit sounds like a
# hit, walking sounds like footsteps, jumping lands with a thud,
# water splashes. MUSIC appears only when the prompt itself asks
# for it or the scene is genuinely musical (the MUSIC GATE).
# Environment ambience stays, phrased as ambience ("soft wind
# through bamboo leaves, distant birdsong"), never as music.
#
# Output shape: a comma list of concrete sounds, most-salient
# action first, e.g. "small footsteps on grass, leaves rustling,
# a soft thud, gentle wind, distant birdsong".
# ---------------------------------------------------------------------------

# Music vocabulary: banned from sound_prompt unless the MUSIC GATE
# is open (the v2 battery asserts this). "song" is deliberately
# NOT banned — "birdsong" is an ambience sound, not music.
_MUSIC_VOCAB = ("music", "orchestral", "orchestra", "piano",
                "synth", "soundtrack", "melody", "drums")

# Action SFX map, ordered most-salient first. EVERY matching rule
# contributes its phrase (v1 returned only the first match), so a
# prompt's full action is heard: run + splash + leaves all land.
# Matching reuses the letter-boundary discipline of
# _match_sound_rules via _sound_rule_hit — short keywords match
# whole words only ("hit" never fires inside "white", "run" never
# inside "trunk"); longer keywords anchor at a word start, and the
# common verb inflections are listed explicitly ("fighting",
# "running", "splashing") instead of relying on stems.
_SOUND_RULES: list[tuple[tuple[str, ...], str]] = [
    # --- impacts and destruction: the loudest, most salient ---
    (("explosion", "explosions", "explode", "explodes", "exploding",
      "blast", "bomb", "bombs"),
     "a deep explosion boom, rumbling falling debris"),
    (("crash", "crashes", "crashing", "shatter", "shatters",
      "shattering", "smash", "smashes", "smashing", "collide",
      "collision"),
     "a loud crash, shattering and cracking debris"),
    (("punch", "punches", "punching", "boxing", "fight", "fights",
      "fighting", "battle", "battles", "combat", "versus",
      "warrior", "ladai"),
     "hard punch impacts, body thuds, grunts of effort, "
     "scuffling movement"),
    (("hit", "hits", "hitting", "kick", "kicks", "kicking",
      "strike", "strikes", "striking", "attack", "attacks",
      "attacking", "slap", "slaps", "sword", "swords", "gun",
      "guns", "shooting", "wrestling"),
     "heavy impact sounds, sharp cracks and thuds, fast "
     "scuffling movement"),
    (("break", "breaks", "breaking", "broken", "crack", "cracks",
      "cracking"),
     "cracking and snapping sounds"),
    # --- weather and water ---
    (("thunder", "lightning", "storm", "stormy"),
     "thunder rumbling, strong wind gusts"),
    (("rain", "rains", "raining", "rainfall", "monsoon", "barish",
      "baarish"),
     "rain pattering steadily, water dripping and splashing"),
    (("waterfall", "aabshar"),
     "a waterfall roaring, misty spray hissing"),
    (("splash", "splashes", "splashing"),
     "water splashing"),
    (("swim", "swims", "swimming"),
     "swimming strokes splashing through water"),
    (("ocean", "sea", "beach", "wave", "waves", "shore", "coast",
      "island", "samandar"),
     "waves rolling and crashing on the shore, water foaming "
     "and splashing"),
    (("river", "stream", "lake", "pool", "darya", "jheel"),
     "gentle flowing water, soft ripples and splashes"),
    (("underwater",),
     "muffled underwater bubbling, deep water movement"),
    # --- falls and jumps (falls matched against a weather-
    # neutralized copy of the text — see _build_sound_prompt) ---
    (("fall", "falls", "fell", "falling", "drop", "drops",
      "dropping", "dropped", "tumble", "tumbles", "tumbling",
      "gir", "gira", "girna"),
     "a falling whoosh, a heavy thud on impact, scattering debris"),
    (("jump", "jumps", "jumping", "leap", "leaps", "leaping",
      "hop", "hops", "hopping", "dive", "dives", "diving"),
     "a quick whoosh through the air, a soft landing thud"),
    # --- locomotion ---
    (("run", "runs", "running", "sprint", "sprints", "sprinting",
      "gallop", "gallops", "galloping"),
     "rapid footsteps pounding, fabric rustling, quick breathing"),
    (("walk", "walks", "walking", "stroll", "strolls", "strolling",
      "step", "steps", "stepping", "stepped", "wander", "wanders",
      "wandering"),
     "steady footsteps, soft fabric rustle"),
    # --- vehicles and machines ---
    (("car", "cars", "truck", "trucks", "engine", "engines",
      "drive", "drives", "driving", "motorcycle", "motorbike",
      "gaari", "gadi"),
     "a running engine, tires humming on the road"),
    (("train", "trains", "railway"),
     "a train rumbling over the rails, rhythmic clatter, a "
     "distant horn"),
    (("bicycle", "bike", "bikes", "cycling"),
     "bicycle wheels whirring, a light chain rattle"),
    (("boat", "boats", "ship", "ships", "sailing", "kashti"),
     "water lapping against the hull, a low engine hum, ropes "
     "creaking"),
    (("airplane", "plane", "planes", "jet", "jets", "rocket",
      "rockets", "jahaz"),
     "a deep engine roar, rushing wind"),
    # Chase/race sits AFTER the vehicle rules on purpose: when a
    # vehicle rule already matched (a car chase), the builder
    # skips this entry — a car chase is engine and tires, not
    # pounding feet. On foot (or on a horse) it is footsteps.
    (("chase", "chases", "chasing", "race", "races", "racing"),
     "rapid footsteps pounding, quick breathing, fabric rustling"),
    # --- flight (butterflies/dragonflies are near-silent and are
    # excluded in the builder) ---
    (("fly", "flies", "flying", "flight", "soaring", "soar",
      "wings"),
     "wind rushing past, wings beating the air"),
    # --- food, doors, fire ---
    (("eat", "eats", "eating", "bite", "bites", "biting", "chew",
      "chews", "chewing", "munch", "munching"),
     "crunching bites, chewing, a sip and a swallow"),
    (("door opens", "opens the door", "opening the door",
      "door opening", "closes the door", "door closes",
      "door closing", "doorbell", "slammed"),
     "a door creaking, a latch clicking"),
    (("fireworks", "firework"),
     "fireworks popping and crackling in the sky"),
    (("campfire", "fireplace", "bonfire", "fire", "candle",
      "candles"),
     "a fire crackling and popping softly"),
    # --- creature calls: only when the animal is in the prompt
    # (presence is the subject proxy — the prompt is about its
    # subject) ---
    (("dog", "dogs", "puppy", "puppies", "barking", "kutta"),
     "a dog barking"),
    (("cat", "cats", "kitten", "kittens", "meowing", "billi"),
     "a cat meowing softly"),
    (("lion", "lions", "sher"),
     "a lion roaring deeply"),
    (("tiger", "tigers"),
     "a tiger growling low"),
    (("horse", "horses", "ghora"),
     "a horse neighing, hooves clopping on the ground"),
    (("elephant", "elephants", "hathi", "haathi"),
     "an elephant trumpeting"),
    (("monkey", "monkeys", "bandar"),
     "monkeys chattering and shrieking"),
    (("cow", "cows"),
     "a cow mooing"),
    (("wolf", "wolves"),
     "a wolf howling"),
    (("duck", "ducks"),
     "ducks quacking"),
    (("chicken", "chickens", "hen", "hens"),
     "chickens clucking"),
    (("frog", "frogs"),
     "frogs croaking"),
    (("owl", "owls"),
     "an owl hooting softly"),
    (("bee", "bees"),
     "bees buzzing"),
    (("snake", "snakes"),
     "a snake hissing"),
    (("whale", "whales"),
     "a whale singing deep calls, ocean water moving"),
    (("parrot", "parrots"),
     "a parrot squawking"),
    # --- people and places with a signature sound ---
    (("crowd", "crowds", "market", "bazaar", "audience",
      "stadium"),
     "a crowd murmuring and cheering, indistinct chatter"),
    (("cafe", "café", "restaurant", "coffee shop", "tea house"),
     "cups and saucers clinking softly, quiet cafe chatter, a "
     "kettle steaming"),
    (("cooking", "frying", "boiling", "kitchen"),
     "food sizzling in a pan, gentle bubbling"),
    (("laugh", "laughs", "laughing", "laughter"),
     "people laughing warmly"),
    (("cry", "cries", "crying", "sobbing"),
     "soft sobbing"),
    (("autumn", "leaves", "leaf pile"),
     "dry leaves rustling and crunching"),
    (("astronaut", "spaceship", "space station", "orbit",
      "galaxy", "space"),
     "a low spacecraft hum, faint radio static, muffled "
     "breathing, deep quiet"),
]

# Environment ambience — always phrased as ambience, never music.
# Collected after the action SFX (at most two phrases).
_AMBIENCE_RULES: list[tuple[tuple[str, ...], str]] = [
    (("bamboo",),
     "soft wind rustling through bamboo leaves, distant birdsong"),
    (("forest", "jungle", "woods", "trees", "jangal"),
     "soft wind rustling through the leaves, distant birdsong"),
    (("meadow", "field", "fields", "garden", "flowers", "valley",
      "bagh"),
     "gentle wind over the grass, distant birdsong"),
    (("savanna",),
     "warm dry wind over grass, distant birdsong"),
    (("mountain", "mountains", "hills", "pahad"),
     "thin mountain wind, distant quiet echoes"),
    (("desert", "dunes", "sahara", "registan"),
     "dry desert wind, soft sand shifting"),
    (("snow", "winter", "frozen", "barf"),
     "soft winter wind, faint snow crunching"),
    (("city", "street", "streets", "urban", "downtown", "skyline",
      "sheher"),
     "distant traffic hum, faint city ambience"),
    (("village", "gaon"),
     "quiet village ambience, distant birdsong"),
    (("concert", "stage", "theater", "theatre"),
     "a lively crowd humming with anticipation, hall ambience"),
    (("office",),
     "quiet office ambience, soft keyboard clicks"),
    (("house", "home", "ghar"),
     "quiet indoor room tone, faint sounds from outside"),
]

# Domain ambience fallbacks — used only when neither an action
# rule's world nor an ambience rule matched. SFX-flavoured, no
# music vocabulary (the v1 beds that lived here are gone).
_SOUND_BY_DOMAIN: dict[str, str] = {
    "animals": "gentle wind through leaves, distant birdsong, "
               "soft nature sounds",
    "nature_landscapes": "gentle wind, distant birdsong, soft "
                         "nature sounds",
    "ocean_weather": "gentle waves washing, soft wind",
    "cities_streets": "distant traffic hum, faint city ambience",
    "space_scifi": "a low steady hum, deep quiet",
    "sports": "a crowd cheering, lively stadium ambience",
    "vehicles": "a running engine, tires on the road",
    "fantasy": "gentle wind, faint magical chimes",
    "festivals_culture": "a cheerful crowd, festive bustle and "
                         "laughter",
    "people_daily_life": "quiet everyday ambience, soft sounds "
                         "of daily life",
    "food": "soft kitchen sounds, gentle sizzling",
    "anime_cartoon": "soft wind, playful everyday ambience",
    "business_tech": "quiet office ambience, soft keyboard clicks",
    "architecture": "soft wind, quiet spacious ambience",
    "abstract_art": "soft flowing wind, gentle water-like sounds",
}

_SOUND_DEFAULT = "soft wind, quiet ambience of the scene"

# ---------------------------------------------------------------------------
# MUSIC GATE — music vocabulary may enter sound_prompt ONLY when
# the prompt itself implies performance/music: a concert, singing,
# dancing, an instrument being played, a party/wedding performance,
# the word "music" itself, or an explicit ask ("with background
# music"). A car chase is NOT musical; a car chase "with
# background music" is — the engine SFX still come first and the
# music phrase is appended last.
# ---------------------------------------------------------------------------
_MUSIC_GATE_KEYWORDS = (
    "concert", "singing", "singer", "singers", "sing", "sings",
    "song", "songs", "dancing", "dance", "dances", "band",
    "guitar", "piano", "violin", "dj", "party", "partying",
    "wedding", "music", "musical", "musician", "musicians",
    "trumpet", "flute", "drums", "drummer", "tabla", "sitar",
    "harmonium", "live music", "stage performance",
)


def _music_gate_open(low: str) -> bool:
    # "birds singing" / "whale singing" are animal calls, not a
    # performance; Roman Urdu "darwaza band" means a CLOSED door,
    # not a band. Neutralize both before matching.
    text = re.sub(r"(birds?|whales?)\s+singing", r"\1", low)
    text = re.sub(r"darwaza\s+band", "darwaza", text)
    return _sound_rule_hit(_MUSIC_GATE_KEYWORDS, text)


def _music_phrase(low: str) -> str:
    """The music description for a gate-open prompt, matched to
    the scene. Only ever appended AFTER the action SFX."""
    if _sound_rule_hit(("concert", "stage", "singer", "singers",
                        "singing", "sing", "song", "songs",
                        "musician", "musicians", "band"), low):
        return "live singing with stage music in the background"
    if _sound_rule_hit(("dj", "party", "partying", "dancing",
                        "dance", "dances", "wedding"), low):
        return "joyful dance music with a lively beat"
    if _sound_rule_hit(("guitar",), low):
        return "soft guitar music playing"
    if _sound_rule_hit(("piano",), low):
        return "gentle piano music playing"
    if _sound_rule_hit(("violin",), low):
        return "soft violin music playing"
    if _sound_rule_hit(("flute",), low):
        return "soft flute music playing"
    if _sound_rule_hit(("trumpet", "drums", "drummer", "tabla",
                        "sitar", "harmonium"), low):
        return "live instrumental music playing"
    return "soft background music matching the scene"


def _sound_rule_hit(keywords, text: str) -> bool:
    """True when any keyword matches `text` under the sound
    system's letter-boundary discipline: short keywords (<=5
    chars) match as whole words only; longer keywords anchor at a
    word start. This is what stops "war" firing inside "warm"
    (the v1 bug), "hit" inside "white", and "run" inside
    "trunk"."""
    for k in keywords:
        if len(k) <= 5:
            if re.search(rf"(?<![a-z]){re.escape(k)}(?![a-z])", text):
                return True
        elif re.search(rf"(?<![a-z]){re.escape(k)}", text):
            return True
    return False


def _match_sound_rules(rules, text: str):
    """First-match form of the sound matcher (kept for callers
    that want a single rule's value)."""
    for keywords, value in rules:
        if _sound_rule_hit(keywords, text):
            return value
    return None


def _build_sound_prompt(low: str, domain: dict | None,
                        dialogue: dict | None = None) -> str:
    """SFX-first sound description for a video prompt (v2).

    Collects EVERY matching action rule (most-salient first),
    then environment ambience, then — only when present — a soft
    speech note for a detected dialogue line, and — only when the
    MUSIC GATE is open — a scene-matched music phrase, last.
    Domain ambience and the neutral default are fallbacks for
    prompts whose world no rule recognized."""
    # "Falling" rain/snow/leaves is weather settling, not a body
    # falling: neutralize those phrases for the whole SFX scan so
    # the fall rule cannot fire on them (the rain/leaves rules
    # still match the surviving nouns). Deliberate decision: bare
    # "fall" inside "waterfall" never fires either — the boundary
    # discipline blocks it (preceded by a letter), and the
    # waterfall has its own rule. Likewise "waves crashing" is
    # water, not a vehicle crash: neutralize it so the crash rule
    # cannot fire (the ocean rule still matches "waves").
    text = re.sub(r"(rain|snow|leaves)\s+falling", r"\1", low)
    text = re.sub(r"waves?\s+crashing|crashing\s+waves?", "waves",
                  text)
    vehicle_phrases = {
        "a running engine, tires humming on the road",
        "a train rumbling over the rails, rhythmic clatter, a "
        "distant horn",
        "bicycle wheels whirring, a light chain rattle",
        "water lapping against the hull, a low engine hum, ropes "
        "creaking",
        "a deep engine roar, rushing wind",
    }
    horse_hit = _sound_rule_hit(("horse", "horses", "ghora"), text)
    parts: list[str] = []
    for keywords, phrase in _SOUND_RULES:
        if phrase in parts:
            continue
        if horse_hit and phrase.startswith("rapid footsteps"):
            # Horses move by hooves, not feet — the horse rule
            # below supplies them; human footstep phrases would
            # be wrong on top.
            continue
        if keywords and keywords[0] == "fly" and (
                "butterfl" in text or "dragonfl" in text):
            # Near-silent wings: no rushing-wind flight sound.
            continue
        if keywords and keywords[0] == "chase" and any(
                p in vehicle_phrases for p in parts):
            # A vehicle chase/race: engine and tires, not feet.
            continue
        if _sound_rule_hit(keywords, text):
            parts.append(phrase)
    parts = parts[:6]
    ambience = [phrase for keywords, phrase in _AMBIENCE_RULES
                if _sound_rule_hit(keywords, text)]
    # One ambience phrase: the first (most specific) match. Two
    # near-identical ambience lines (bamboo wind + forest wind)
    # only dilute the conditioning text.
    if ambience and ambience[0] not in parts:
        parts.append(ambience[0])
    if not parts and domain and domain["id"] in _SOUND_BY_DOMAIN:
        # Domain ambience is a fallback for a prompt whose world
        # no rule recognized at all — never stacked on top of
        # matched SFX (it used to duplicate them: the vehicles
        # bed echoed the engine rule, sports added a stadium
        # crowd to a boy hitting a ball in a park).
        parts.append(_SOUND_BY_DOMAIN[domain["id"]])
    if not parts:
        parts.append(_SOUND_DEFAULT)
    if dialogue:
        # The exact words are spoken by the voice stage (phase 2);
        # the sound bed only notes natural speech — MMAudio must
        # not invent fake words of its own.
        parts.append("natural voices speaking softly in the scene")
    if _music_gate_open(low):
        parts.append(_music_phrase(low))
    return ", ".join(parts)


# ---------------------------------------------------------------------------
# Dialogue detection (design + field; the runner wiring is phase
# 2). A prompt that quotes a spoken line — "the old man says:
# 'I will never give up'" — wants those EXACT words heard. The
# line is extracted verbatim here; in phase 2 the runner speaks it
# with Kokoro timed over the SFX bed with the ambience ducked.
# That is correct-words dubbing, NOT true lip-sync — the fleet has
# no lip-sync model, and nothing here claims otherwise.
# ---------------------------------------------------------------------------

_DIALOGUE_QUOTE_RE = re.compile(
    r"[\"“]([^\"”\n]{2,160})[\"”]|\'([^\'\n]{2,160})\'")

_SAY_HINTS = (
    "says", "said", "say", "shouts", "shouted", "whispers",
    "whispered", "asks", "asked", "replies", "replied", "exclaims",
    "keh raha", "keh rahi", "bol raha", "bol rahi", "kaha",
)

# Speaker hints: people words (English + Roman Urdu) and common
# character subjects. The hint nearest before the quote wins.
_SPEAKER_HINTS = (
    "old man", "young man", "young woman", "old woman", "man",
    "woman", "boy", "girl", "child", "baby", "father", "mother",
    "king", "queen", "panda", "robot", "cat", "dog", "ladka",
    "ladki", "aadmi", "aurat", "bacha", "bachi",
)


def _detect_dialogue(original: str) -> dict | None:
    """Extract a quoted spoken line from the raw prompt.

    Returns {"line": <verbatim line>, "speaker": <hint or ''>} or
    None. A quote is accepted when it is multi-word, or when a
    say/shout/whisper hint appears anywhere in the (short) prompt
    — this keeps scare quotes and contractions ("don't") from
    becoming dialogue."""
    m = _DIALOGUE_QUOTE_RE.search(original or "")
    if not m:
        return None
    line = (m.group(1) or m.group(2) or "").strip()
    if not line:
        return None
    low = (original or "").lower()
    has_say = _sound_rule_hit(_SAY_HINTS, low)
    if " " not in line and not has_say:
        return None
    before = low[:m.start()]
    speaker = ""
    best = -1
    for hint in _SPEAKER_HINTS:
        for hit in re.finditer(
                rf"(?<![a-z]){re.escape(hint)}(?![a-z])", before):
            if hit.end() > best:
                best = hit.end()
                speaker = _URDU_WORDS.get(hint, hint)
    return {"line": line, "speaker": speaker}


def _strip_quoted_line(translated: str) -> str:
    """Remove the quoted spoken line from the VISUAL subject text.

    The line is delivered by the dialogue dubbing stage (Kokoro), so
    the video model must never see the words: given the quote it tries
    to DRAW the text and produces garbled pseudo-lettering on the
    character (proven live 2026-10-17: the old-man dialogue test wore
    scrambled text across his torso). The speech framing itself
    ("...and says") is harmless and stays, so the character still
    reads as speaking. Only the first quote span — the one
    _detect_dialogue extracted — is removed; punctuation left
    dangling at the cut is tidied.
    """
    text = _DIALOGUE_QUOTE_RE.sub("", translated or "", count=1)
    text = re.sub(r"\s+([,.;:])", r"\1", text)
    text = re.sub(r"([,;:])\s*([,.;:])", r"\2", text)
    text = re.sub(r"\s{2,}", " ", text).strip()
    text = text.rstrip(" ,;:").rstrip(".")
    return text or (translated or "").rstrip(".")


def _build_scenes(subject: str, detail_clauses: list[str],
                  tail_parts: list[str]) -> list[str]:
    """Split a heavy video request into [setup, payoff] scene prompts.

    The character anchor — the subject sentence plus the
    subject-consistency lock clause when present — is reproduced
    VERBATIM at the head of both scenes; only the beat differs.
    ``tail_parts`` are the enhanced prompt's shared clauses (camera,
    lighting, mood, style/domain tokens, remaining detail clauses,
    motion/quality, composition) minus the lock clause itself, which
    already lives inside the anchor."""
    lock = next((c for c in detail_clauses
                 if c.startswith("one single ")), None)
    anchor = subject if not lock else f"{subject}, {lock}"
    anchor = anchor[0].upper() + anchor[1:]
    tail = ", ".join(p.strip().rstrip(",") for p in tail_parts
                     if p and p != lock)
    setup_beat = (
        "the scene opens and the subject is revealed in the "
        "environment, poised and ready, anticipation building in "
        "the moments just before the main action"
    )
    payoff_beat = (
        f"the main action in full motion: {subject}, the decisive "
        "climax of the scene, dynamic and powerful"
    )
    return [
        f"{anchor}. {setup_beat[0].upper() + setup_beat[1:]}, {tail}.",
        f"{anchor}. {payoff_beat[0].upper() + payoff_beat[1:]}, {tail}.",
    ]


def enhance_prompt(
    user_prompt: str,
    style: str = DEFAULT_STYLE,
    aspect: str = "16:9",
    duration: float = 3,
    domain_id: str | None = None,
    kind: str = "video",
) -> dict:
    """Expand a short user prompt into a Wan-ready prompt + negative prompt.

    The all-in-one curriculum (data/curriculum/domains.json) drives domain
    detection and template choice: a detected (or explicitly chosen) domain
    contributes its default camera/lighting and its extra tokens.

    Returns a dict with: original, translated, enhanced_prompt,
    negative_prompt, camera, lighting, mood, style, domain — plus,
    for video jobs, sound_prompt (the SFX-first sound description,
    v2) and scenes (heavy jobs only: [setup, payoff] scene prompts
    sharing one verbatim character anchor; [] for normal
    durations) and dialogue ({"line", "speaker"} when the prompt
    quotes a spoken line, else None).
    """
    original = (user_prompt or "").strip()
    if not original:
        raise ValueError("prompt must not be empty")

    # If the text leans Roman Urdu, translate content words first.
    translated = translate_roman_urdu(original) if _urdu_score(original) >= 2 else original
    low = translated.lower()

    domain = get_domain(domain_id) or detect_domain(f"{translated} {original}")

    preset = STYLE_PRESETS.get(style, STYLE_PRESETS[DEFAULT_STYLE])
    camera = (
        _match_rules(_CAMERA_RULES, low)
        or (domain or {}).get("camera_default")
        or _pick(_CAMERA_FALLBACKS, original)
    )
    if not _clause_allowed(camera, low, original.lower()):
        # Heuristic boilerplate from a world the user never asked
        # for (vehicle/water) — replace with a neutral move. The
        # fallbacks carry no gated terms, so this always passes.
        camera = _pick(_CAMERA_FALLBACKS, original)
    lighting = (
        _match_rules(_LIGHTING_RULES, low)
        or (domain or {}).get("lighting_default")
        or preset["lighting"]
    )
    mood = _match_rules(_MOOD_RULES, low)

    subject = translated.rstrip(".")

    # Dialogue (video only): extract the quoted spoken line for the
    # dubbing stage, and keep those words OUT of the visual subject
    # (see _strip_quoted_line). Rule matching below still uses the
    # full text — only the rendered subject changes.
    dialogue = _detect_dialogue(original) if kind == "video" else None
    if dialogue:
        subject = _strip_quoted_line(translated)

    if kind == "audio":
        # Audio jobs get a simple production template, no visual tokens.
        return {
            "original": original,
            "translated": translated,
            "enhanced_prompt": (
                f"High-quality audio recording: {subject}. "
                "Clear, professionally produced, well-mixed, "
                "no background noise."
            ),
            "negative_prompt": (
                "low quality, distortion, clipping, background noise, "
                "hiss, hum, muffled, echo"
            ),
            "camera": "",
            "lighting": "",
            "mood": mood or "",
            "style": style,
            "domain": domain["id"] if domain else "",
            "kind": kind,
            "sound_prompt": "",
            "scenes": [],
            "dialogue": None,
        }

    parts = [
        subject,
        camera,
        lighting,
    ]
    if mood:
        parts.append(mood)
    parts.append(preset["tokens"])
    if domain:
        # Domain extra tokens are boilerplate too: the ocean domain
        # must not paste "dynamic sky and water" onto a snow scene.
        extra_tokens = domain["extra_tokens"]
        if _clause_allowed(extra_tokens, low, original.lower()):
            parts.append(extra_tokens)
    detail_clauses, wants_text = _detail_clauses(low)
    parts.extend(detail_clauses)
    if kind == "image":
        # Still image: count lock + anti-duplication clauses (the
        # duplication/fusion lesson — see the hardening section).
        # They sit mid-prompt in the normal clause stream, where
        # the model actually reads them; a CFG-0 engine ignores
        # the negative prompt entirely, so the positive wording is
        # the lever that reaches SDXL-Turbo today, and FLUX follows
        # explicit count language as well.
        parts.extend(_image_hardening_clauses(low, original))
        # Still image: no motion language.
        parts.append("high quality, sharp details, crisp focus, rich detail")
    else:
        parts.append(
            "high quality, sharp details, smooth continuous motion, "
            "consistent subject across frames, physically plausible movement"
        )
    if aspect == "9:16":
        parts.append("vertical composition")
    elif aspect == "1:1":
        parts.append("centered square composition")

    enhanced = ", ".join(p.strip().rstrip(",") for p in parts if p)
    enhanced = enhanced[0].upper() + enhanced[1:] + "."

    negative = _BASE_NEGATIVE
    if wants_text:
        # The user asked FOR text/a logo: stop banning what was requested.
        negative = negative.replace("watermark, logo, text, ", "")
    if style == "photorealistic":
        negative += ", cartoon, anime, CGI look, plastic skin"
    elif style == "anime":
        negative += ", photorealistic, 3d render, live action"
    if kind == "image":
        # Image jobs carry the real duplication/fusion negative
        # set (engines that honour negatives, incl. the FLUX
        # lane). None of these terms bans text, so the wants_text
        # exception above is untouched. Plural-intent images get
        # only the fusion/anatomy subset — never terms that could
        # suppress a count the user asked for (see the hardening
        # section).
        negative += (
            _IMAGE_NEGATIVE_PLURAL if _plural_intent(low, original)
            else _IMAGE_NEGATIVE_SINGLE
        )

    # Sound design + (heavy only) scene structure — video only.
    # (dialogue was extracted earlier, where the visual subject is
    # built, so the spoken words never reach the video model.)
    sound_prompt = ""
    scenes: list[str] = []
    if kind == "video":
        sound_prompt = _build_sound_prompt(low, domain,
                                           dialogue=dialogue)
        if float(duration) >= config.HEAVY_DURATION:
            # parts[0] is the subject; parts[1:] are the shared
            # clauses the two scene prompts inherit unchanged.
            scenes = _build_scenes(subject, detail_clauses, parts[1:])

    return {
        "original": original,
        "translated": translated,
        "enhanced_prompt": enhanced,
        "negative_prompt": negative,
        "detail_notes": detail_clauses,
        "camera": camera,
        "lighting": lighting,
        "mood": mood or "",
        "style": style,
        "domain": domain["id"] if domain else "",
        "kind": kind,
        "sound_prompt": sound_prompt,
        "scenes": scenes,
        "dialogue": dialogue,
    }
