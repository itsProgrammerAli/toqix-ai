"""TOQIX all-in-one curriculum — loader + domain detection.

The curriculum (data/curriculum/domains.json) is how the owner's
"train it on everything" instruction is implemented in practice:
a taxonomy of all major video domains with bilingual example prompts
and caption templates. The prompt engine uses it for domain detection
and template choice; the Studio exposes it for balanced batch jobs;
the flywheel curates training data across the same domains.
"""

from __future__ import annotations

import json
import re
from functools import lru_cache

from . import config


@lru_cache(maxsize=1)
def load_domains() -> list[dict]:
    data = json.loads(config.DOMAINS_PATH.read_text(encoding="utf-8"))
    return data["domains"]


def get_domain(domain_id: str | None) -> dict | None:
    if not domain_id:
        return None
    for domain in load_domains():
        if domain["id"] == domain_id:
            return domain
    return None


# Plural false friends: keyword+"s" forms that are a DIFFERENT
# real word, not the keyword's plural. "pari" (Roman Urdu: fairy)
# + "s" spells "paris" (the city) — without this exception the
# boundary matcher would route Paris prompts to fantasy through
# the back door it just closed.
_PLURAL_FALSE_FRIENDS: dict[str, set[str]] = {
    "pari": {"paris"},
}


def _keyword_forms(kw: str) -> set[str]:
    """Whole-word forms a curriculum keyword may take in text: the
    keyword itself plus its plurals ("s", "es" after s/x/z/ch/sh,
    "y" -> "ies", so "butterfly" also matches "butterflies" and
    "city" matches "cities"), minus known false friends."""
    forms = {kw, kw + "s"}
    if kw.endswith(("s", "x", "z", "ch", "sh")):
        forms.add(kw + "es")
    if kw.endswith("y"):
        forms.add(kw[:-1] + "ies")
    return forms - _PLURAL_FALSE_FRIENDS.get(kw, set())


def detect_domain(text: str) -> dict | None:
    """Score the text against every domain's keyword list (English +
    Roman Urdu keywords) and return the best-matching domain, or None.

    Keywords match as WHOLE WORDS (plurals allowed), never as raw
    substrings — the owl lesson (2026-10-17, job fdef9d8624db): the
    old substring scan let "ink" fire inside "pink" (and every real
    domain scored zero), routing a turtle video to abstract_art.
    The same hazard family: "rang" inside "orange", "car" inside
    "cartoon", "sea" inside "season", "pari" inside "paris".
    Multi-word keywords match as bounded phrases."""
    low = text.lower()
    tokens = set(re.findall(r"[a-z0-9]+", low))
    best, best_hits = None, 0
    for domain in load_domains():
        hits = 0
        for kw in domain.get("keywords", []):
            k = kw.lower()
            if " " in k:
                if re.search(rf"(?<![a-z0-9]){re.escape(k)}(?![a-z0-9])", low):
                    hits += 1
            elif _keyword_forms(k) & tokens:
                hits += 1
        if hits > best_hits:
            best, best_hits = domain, hits
    return best if best_hits > 0 else None
