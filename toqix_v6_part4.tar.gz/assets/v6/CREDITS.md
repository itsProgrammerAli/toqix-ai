# TOQIX Control Room v6 — asset credits

## Characters & animations — Mixamo (Adobe)
- Character models (Remy, Sophie, Jody, Brian, Kate, James) and all animation
  clips (idle / walk / run / carry / typing / sitting / waving / talking /
  jump / roll / door / dance / pointing / picking up) are from **Mixamo**
  (https://www.mixamo.com), downloaded with the owner's Adobe account.
- Licence: Mixamo content is royalty-free for use in commercial and
  non-commercial projects per Adobe's Mixamo terms (content may not be
  redistributed as standalone assets). Used here as animated characters
  inside the TOQIX Control Room scene.
- FBX → glTF conversion done locally with Blender 5.2.2
  (`patches/convert_v6_assets.py`): textures downscaled to max 1024 px
  (JPEG) to keep the web payload small; no geometry changes.

## Environment — Sponza (Crytek / Khronos glTF samples)
- The courtyard is the **Sponza** scene (originally Crytek; glTF version
  from the KhronosGroup glTF-Sample-Models repository, CC-BY 4.0 for the
  glTF conversion — see the sample model's licence).
- Textures downscaled to max 1024 px (JPEG q82) for web delivery; geometry
  unchanged. One primitive — the model's oversized exterior base sheet —
  is hidden at runtime because it slices through the courtyard interior
  (see `web/control_v6.html`).

## Libraries
- three.js r128 (MIT) — `web/vendor/three.min.js`, `GLTFLoader.js`,
  `assets/v6/vendor/OrbitControls.js`.

## Props & badges
- Desk, monitor, stool, crates and the chest name-badges are original
  geometry/canvas textures created for this project (no external assets).
