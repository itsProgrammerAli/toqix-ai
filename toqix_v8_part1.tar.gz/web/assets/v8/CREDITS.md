# TOQIX AI WORLD v8 — asset credits

Every hero model in the v8 city is a real downloaded asset (CC0 / CC-BY
only), normalised to real-world scale with Blender (grounded, centred,
textures capped at 1024 px, many-part models joined). Converted files
live in this folder; the page loads them from /static/assets/v8/.

CC-BY assets require attribution — this file is that attribution.
"Poly by Google" models are from the Google Poly library (CC-BY 3.0).

## Vehicles — source: poly.pizza

| File | Model | Author | Licence | Source |
|---|---|---|---|---|
| cars/car_rx7.glb | Mazda RX-7 | IvOfficial | CC-BY 3.0 | https://poly.pizza/m/SnIoWlh7S2 |
| cars/car_charger.glb | Dodge Charger | David Sirera | CC-BY 3.0 | https://poly.pizza/m/4b80hRVxqvv |
| cars/car_police.glb | Police Car | Quaternius | CC0 1.0 | https://poly.pizza/m/BwwnUrWGmV |
| cars/car_pickup.glb | Pickup Truck | Quaternius | CC0 1.0 | https://poly.pizza/m/qn4grQgHm8 |
| cars/car_suv.glb | SUV | Quaternius | CC0 1.0 | https://poly.pizza/m/xsMtZhBkxL |
| cars/car_bus.glb | Bus | Poly by Google | CC-BY 3.0 | https://poly.pizza/m/4CPpvEmrMoF |
| cars/car_van.glb | Van | Poly by Google | CC-BY 3.0 | https://poly.pizza/m/aT_24cDaW1a |
| cars/car_wagon.glb | Car (wagon) | Poly by Google | CC-BY 3.0 | https://poly.pizza/m/75h3mi6uHuC |
| cars/bike_sport.glb | Motorcycle | Poly by Google | CC-BY 3.0 | https://poly.pizza/m/dse64pqMKAR |
| cars/bike_vespa.glb | Vespa | Jasmine Roberts | CC-BY 3.0 | https://poly.pizza/m/blGLclvvdEM |

## Buildings — source: poly.pizza

| File | Model | Author | Licence | Source |
|---|---|---|---|---|
| buildings/b_tower_slab.glb | Distant Building 03 (GPU TOWER — KAGGLE) | Jarlan Perez | CC-BY 3.0 | https://poly.pizza/m/7zyZfQrt3ZP |
| buildings/b_tower_panel.glb | Skyscraper (GPU TOWER — COLAB) | burunduk | CC-BY 3.0 | https://poly.pizza/m/NcMARBzYKG |
| buildings/b_drivehq.glb | Hotel (DRIVE HQ) | Poly by Google | CC-BY 3.0 | https://poly.pizza/m/3ZMq1s7B76q |
| buildings/b_apartment.glb | Apartment building (TRAINING ACADEMY) | Poly by Google | CC-BY 3.0 | https://poly.pizza/m/01lqee-dZAr |
| buildings/b_corner.glb | The Corner Store (VIDEO STUDIOS) | VR XRTIST | CC-BY 3.0 | https://poly.pizza/m/8sfezIjI4KE |
| buildings/b_georgian.glb | Big Building (SOUND STUDIO) | Quaternius | CC0 1.0 | https://poly.pizza/m/AVCS8jUd2l |
| buildings/b_cinema.glb | Cinema (CINEMA) | Poly by Google | CC-BY 3.0 | https://poly.pizza/m/c-5balfj4bu |
| buildings/b_townhouse.glb | Town House (KNOWLEDGE LIBRARY / MODEL WAREHOUSE) | Quaternius | CC0 1.0 | https://poly.pizza/m/imVkxz7oZD |
| buildings/b_house.glb | House (AGENT HOUSE / REST HOUSE) | burunduk | CC-BY 3.0 | https://poly.pizza/m/xa9HeFAahI |
| buildings/b_empire.glb | Skyscraper (skyline landmark) | Poly by Google | CC-BY 3.0 | https://poly.pizza/m/dIsZyy2FUY- |

## Trees & props — source: poly.pizza

| File | Model | Author | Licence | Source |
|---|---|---|---|---|
| trees/tree_big.glb | Big Tree | 3Donimus | CC-BY 3.0 | https://poly.pizza/m/dNWh762PN-6 |
| trees/tree_palm.glb | Queen Palm Tree | Poly by Google | CC-BY 3.0 | https://poly.pizza/m/ficLBIjGliK |
| trees/tree_street.glb | Tree (foliage darkened in conversion) | Marc Solà | CC-BY 3.0 | https://poly.pizza/m/6Yjt8nIwLsD |
| props/prop_rack.glb | Server Rack | Jeremy Eyring | CC-BY 3.0 | https://poly.pizza/m/6ijQclm8jxw |
| props/prop_container.glb | Shipping Container | Clint Chilcott | CC-BY 3.0 | https://poly.pizza/m/dlBoC4Wkzp2 |
| furniture/f_officechair.glb | Office Chair | CMHT Oculus | CC-BY 3.0 | https://poly.pizza/m/dCEsSsJJ1Md |
| furniture/f_monitor.glb | Monitor | CreativeTrio | CC0 1.0 | https://poly.pizza/m/PvSjEbz11k |

## Furniture & street furniture — source: Poly Haven (all CC0 1.0)

| File | Model | Source |
|---|---|---|
| furniture/f_desk.glb | Metal Office Desk | https://polyhaven.com/a/metal_office_desk |
| furniture/f_armchair.glb | Modern Arm Chair 01 | https://polyhaven.com/a/modern_arm_chair_01 |
| furniture/f_chair2.glb | Green Chair 01 | https://polyhaven.com/a/GreenChair_01 |
| furniture/f_sofa.glb | Sofa 01 | https://polyhaven.com/a/Sofa_01 |
| furniture/f_plant.glb | Potted Plant 04 | https://polyhaven.com/a/potted_plant_04 |
| furniture/f_screen.glb | Projector Screen | https://polyhaven.com/a/projector_screen |
| furniture/f_coffeetable.glb | Modern Coffee Table 01 | https://polyhaven.com/a/modern_coffee_table_01 |
| furniture/f_bench.glb | Painted Wooden Bench | https://polyhaven.com/a/painted_wooden_bench |
| furniture/f_streetlamp.glb | Street Lamp 01 | https://polyhaven.com/a/street_lamp_01 |
| furniture/f_planter.glb | Planter Box 01 | https://polyhaven.com/a/planter_box_01 |
| furniture/f_bookshelf.glb | Wooden Bookshelf Worn | https://polyhaven.com/a/wooden_bookshelf_worn |
| furniture/f_table_big.glb | Dining Table | https://polyhaven.com/a/dining_table |
| furniture/f_chair_dining.glb | Dining Chair 02 | https://polyhaven.com/a/dining_chair_02 |

## Ground textures — Poly Haven via the v7 texture set (CC0 1.0)

Asphalt, concrete pavement, leafy grass, painted concrete, concrete block
wall, grey roof tiles, painted brick, sandstone blocks — reused in place
from web/assets/v7/tex/ (see web/assets/v7/CREDITS.md).

## Characters

The six-person Mixamo cast (Remy, Sophie, Jody, Brian, Kate, James) and
their animation clips are reused in place from web/assets/v6/ — see the
v6 handoffs. Citizens, commuters and the player are retinted instances of
the same rigs (the dedicated Mixamo citizen downloads never reached disk
on 2026-10-17, so citizens remain placeholders — stated plainly in
HANDOFF_control_room_v8.md).

## The HQ building itself

The headquarters is purpose-built geometry (the one structural exception
in the spec: it must contain working rooms, doors and a staircase),
dressed entirely with the downloaded furniture/props above. Its facade
sign is drawn in code in the same struck-metal family as the cast's
police badges and the district signs.
