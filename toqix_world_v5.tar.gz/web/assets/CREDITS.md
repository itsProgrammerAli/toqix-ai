# TOQIX AI WORLD — asset credits & licences (Control Room v5, 2026-10-17)

Every 3D model on the Control Room page was downloaded from the sources
below and is self-hosted under `web/assets/` — the page makes **no
external requests at runtime**. All models are **CC0 1.0 (public
domain)**; nothing was purchased, and no attribution is legally
required — it is recorded here anyway because the authors deserve it.

## Characters — `assets/chars/`

| Files | What it is | Author | Source | Licence |
|---|---|---|---|---|
| `blocky-a.glb` … `blocky-h.glb` + `Textures/texture-*.png` | Blocky Characters 2.0 — 8 rigged characters. Clips used: idle, walk, sprint, sit, pick-up, holding-both, interact-right/left, emote, attack | Kenney (kenney.nl) | https://kenney.nl/assets/blocky-characters (zip: kenney_blocky-characters_20.zip) | CC0 1.0 |
| `woman.glb` | "Animated Woman" — the Fleet Manager. Clips used: Idle_Neutral, Walk, Run, Wave, Interact | Quaternius | https://poly.pizza/m/qJ2gsTUBHL | CC0 1.0 |
| `hoodie.glb` | "Hoodie Character" — the Wizard. Clips used: Idle_Neutral, Walk, Run, Interact | Quaternius | https://poly.pizza/m/gKLBoRsyKe | CC0 1.0 |

## City — `assets/city/`

All Kenney city kits, CC0 1.0, each with its own `Textures/colormap.png`:

| Folder | Kit | Source |
|---|---|---|
| `city/suburban/` | City Kit Suburban (building-type-a…h, tree-large/small, planter) | https://kenney.nl/assets/city-kit-suburban |
| `city/commercial/` | City Kit Commercial (building-a…d, building-skyscraper-a…e, low-detail-building-a…c, detail-awning) | https://kenney.nl/assets/city-kit-commercial |
| `city/roads/` | City Kit Roads (road-straight, road-crossroad, road-square, light-square, traffic-light, road-sign-street, dumpster, construction-cone, electricity-pole, …) | https://kenney.nl/assets/city-kit-roads |
| `city/nature/` | Nature Kit (tree_default, tree_detailed, tree_cone, tree_fat, plant_bush, plant_bushLarge — vertex-coloured, no texture) | https://kenney.nl/assets/nature-kit |
| `city/car/` | Car Kit (sedan, taxi, delivery, suv) | https://kenney.nl/assets/car-kit |

## Libraries — `web/vendor/`

| File | Library | Licence |
|---|---|---|
| `three.min.js` | Three.js r128 (unchanged from v4) | MIT |
| `GLTFLoader.js` | Three.js r128 examples/js loader, from the three.js GitHub tag `r128` | MIT |
| `SkeletonUtils.js` | Three.js r128 examples/js utils, same source | MIT |

The v4 page is preserved at `web/control_v4_backup.html` (not linked)
for rollback; see `HANDOFF_control_room_v5.md`.
